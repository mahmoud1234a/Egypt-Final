# Project memory

## Product intent & audience

- Grand Egyptian Museum (Giza) public-facing website.
- Fully bilingual Arabic and English; Arabic is primary communication language for the user (Egyptian dialect).
- Interactive multimedia content galleries showcasing museum artifacts/exhibits.
- Production-quality, feature-rich front-end — not a demo or prototype.

## Brand personality & voice

- Pharaonic-inspired aesthetic: golden tones, Egyptian motifs, monumental feel.
- Cultural reverence and grandeur; museum-grade presentation.
- Bilingual voice with equal polish in Arabic (RTL) and English (LTR).

## Visual design & UX direction

- Light and dark theme support (both fully styled).
- Custom golden cursor as a signature interaction element.
- Pharaonic color palette: gold, deep blue, sandstone, dark lapis for dark mode.
- Tailwind CSS for all styling; Lucide React for icons.
- RTL layout must activate for Arabic; LTR for English.
- Multimedia galleries with interactive content.
- Responsive across mobile and desktop.

## Decisions, constraints & rationale

- Stack: React + Vite, JSX, Tailwind CSS, React hooks, Lucide React icons only — no extra UI/icon packages.
- Path alias `@/` → `src/` for all project module imports; no deep relative paths.
- **Critical:** Source files (pages, App.tsx, components) must live inside `src/`. A previous bug placed `App.tsx` and page files in the project root, breaking `@/pages/...` imports and `main.tsx`'s `./App.tsx` import — fixed by relocating to `src/`.
- Expected structure: `src/App.tsx`, `src/main.tsx`, `src/pages/`, `src/components/`.
- User communicates in Egyptian Arabic; respond in Arabic unless context shifts.

## Open questions & assumptions

- i18n approach not yet confirmed — assumed custom React context or lightweight solution (no extra packages installed).
- Translation string storage location assumed under `src/` (e.g., `src/locales/` or `src/i18n/`).
- Theme switching mechanism assumed via React context + Tailwind class strategy.
- Content (artifact data, gallery media) source not yet defined — may need a data file or API integration.