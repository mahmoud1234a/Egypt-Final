(() => {
const $ = s => document.querySelector(s);
const form = $('#form'), F = n => form.elements[n];
let cfg, slotsData = [];
const fmt = n => `${n.toLocaleString('ar-EG')} ${cfg.currency}`;
const fmtDate = d => d ? new Date(d + 'T00:00:00').toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '—';
const setErr = (n, m) => { const el = document.querySelector(`.err[data-for="${n}"]`), inp = form.elements[n]; if (el) el.textContent = m || ''; if (inp && inp.setAttribute) inp.setAttribute('aria-invalid', m ? 'true' : 'false'); };
const clearErrs = () => { ['name','email','phone','location','date','visitors','slot'].forEach(n => setErr(n, '')); $('#formAlert').hidden = true; };
const loc = () => cfg.locations.find(l => l.id === F('location').value);
const slotVal = () => (form.querySelector('input[name=slot]:checked') || {}).value || '';
const vis = () => Math.max(1, Math.min(cfg.maxVisitors, parseInt(F('visitors').value, 10) || 1));

function summary() {
  const l = loc(), v = vis();
  $('#sLoc').textContent = l ? l.name : '—'; $('#sDate').textContent = fmtDate(F('date').value);
  $('#sSlot').textContent = slotVal() || '—'; $('#sUnit').textContent = l ? fmt(l.price) : '—';
  $('#sVis').textContent = v.toLocaleString('ar-EG'); $('#sTotal').textContent = l ? fmt(l.price * v) : '—';
}

async function loadSlots() {
  const box = $('#slots'), l = F('location').value, d = F('date').value;
  if (!l || !d) { box.innerHTML = '<p class="hint">اختر المكان والتاريخ لعرض المواعيد.</p>'; return summary(); }
  box.innerHTML = '<p class="hint">جارٍ تحميل المواعيد…</p>';
  try {
    const r = await fetch(`/api/availability?location=${encodeURIComponent(l)}&date=${encodeURIComponent(d)}`);
    if (!r.ok) throw 0; slotsData = (await r.json()).slots;
  } catch { box.innerHTML = '<p class="hint">تعذّر تحميل المواعيد. حدّث الصفحة وحاول مرة أخرى.</p>'; return; }
  box.innerHTML = '';
  slotsData.forEach(({ slot, remaining }) => {
    const w = document.createElement('label'); w.className = 'slot';
    const i = document.createElement('input'); i.type = 'radio'; i.name = 'slot'; i.value = slot; i.disabled = remaining < 1;
    const s = document.createElement('span'); s.textContent = slot;
    const sm = document.createElement('small'); sm.textContent = remaining < 1 ? 'مكتمل' : `متبقي ${remaining.toLocaleString('ar-EG')}`; s.appendChild(sm);
    i.addEventListener('change', () => { setErr('slot', ''); summary(); });
    w.append(i, s); box.appendChild(w);
  });
  summary();
}

function clientValidate() {
  const e = {}; const g = n => F(n).value.trim();
  if (g('name').length < 3) e.name = 'من فضلك أدخل الاسم الكامل (3 أحرف على الأقل).';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(g('email'))) e.email = 'أدخل بريدًا إلكترونيًا صحيحًا.';
  if (!/^\+?[0-9\s-]{8,16}$/.test(g('phone')) || g('phone').replace(/\D/g, '').length < 8) e.phone = 'أدخل رقم هاتف صحيحًا (8 إلى 15 رقمًا).';
  if (!F('location').value) e.location = 'اختر المكان.';
  if (!g('date')) e.date = 'اختر تاريخ الزيارة.'; else if (g('date') < cfg.minDate) e.date = 'لا يمكن الحجز في تاريخ سابق.'; else if (g('date') > cfg.maxDate) e.date = 'التاريخ بعيد جدًا.';
  const v = parseInt(F('visitors').value, 10); if (!(v >= 1 && v <= cfg.maxVisitors)) e.visitors = `عدد الزوار من 1 إلى ${cfg.maxVisitors}.`;
  if (!slotVal()) e.slot = 'اختر موعدًا متاحًا.';
  return e;
}

form.addEventListener('submit', async ev => {
  ev.preventDefault(); clearErrs();
  const e = clientValidate();
  if (Object.keys(e).length) { Object.entries(e).forEach(([k, m]) => setErr(k, m)); const first = form.querySelector('[aria-invalid=true]') || $('#slots'); first.scrollIntoView({ block: 'center', behavior: 'smooth' }); if (first.focus) first.focus({ preventScroll: true }); return; }
  const btn = $('#submit'); btn.disabled = true; btn.textContent = 'جارٍ تأكيد الحجز…';
  try {
    const r = await fetch('/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
      name: F('name').value, email: F('email').value, phone: F('phone').value, location: F('location').value, date: F('date').value, slot: slotVal(), visitors: vis() }) });
    const data = await r.json().catch(() => ({}));
    if (r.ok && data.ok) return showDone(data);
    if (data.errors) Object.entries(data.errors).forEach(([k, m]) => setErr(k, m));
    if (r.status === 409) loadSlots();
    const a = $('#formAlert'); a.textContent = data.message || 'حدث خطأ غير متوقع. حاول مرة أخرى.'; a.className = 'alert'; a.hidden = false;
  } catch {
    const a = $('#formAlert'); a.textContent = 'تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم أعد المحاولة. لم يتم تأكيد حجزك.'; a.className = 'alert'; a.hidden = false;
  } finally { btn.disabled = false; btn.textContent = 'تأكيد الحجز'; }
});

function showDone({ booking: b, emailStatus }) {
  $('#bookingView').hidden = true; $('#doneView').hidden = false;
  $('#doneId').textContent = b.id;
  $('#doneMsg').textContent = emailStatus === 'sent' ? `تم حفظ حجزك وأرسلنا رسالة التأكيد إلى ${b.email}.` : 'تم حفظ حجزك بنجاح. تعذّر إرسال رسالة البريد الآن، فاحتفظ برقم الحجز أدناه.';
  const d = $('#doneDetails'); d.innerHTML = '';
  [['الاسم', b.name], ['المكان', b.location], ['التاريخ', fmtDate(b.date)], ['الموعد', b.slot], ['عدد الزوار', b.visitors.toLocaleString('ar-EG')], ['الإجمالي', fmt(b.total)]].forEach(([k, v]) => {
    const row = document.createElement('div'), dt = document.createElement('dt'), dd = document.createElement('dd'); dt.textContent = k; dd.textContent = v; row.append(dt, dd); d.appendChild(row); });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

(async function init() {
  try { cfg = await (await fetch('/api/config')).json(); } catch { document.body.insertAdjacentHTML('afterbegin', '<p style="padding:2rem;text-align:center">تعذّر تحميل نظام الحجز.</p>'); return; }
  const sel = F('location'); sel.innerHTML = '<option value="">اختر المكان</option>';
  cfg.locations.forEach(l => { const o = document.createElement('option'); o.value = l.id; o.textContent = `${l.name} – ${l.price.toLocaleString('ar-EG')} ${cfg.currency}`; sel.appendChild(o); });
  if (cfg.locations.length === 1) sel.value = cfg.locations[0].id;
  F('date').min = cfg.minDate; F('date').max = cfg.maxDate; F('visitors').max = cfg.maxVisitors;
  ['#homeLink', '#backBtn'].forEach(s => { if (cfg.museumUrl) $(s).href = cfg.museumUrl; });
  const preset = new URLSearchParams(location.search).get('location'); if (preset && cfg.locations.some(l => l.id === preset)) sel.value = preset;
  sel.addEventListener('change', () => { setErr('location', ''); loadSlots(); }); F('date').addEventListener('change', () => { setErr('date', ''); loadSlots(); });
  F('visitors').addEventListener('input', () => { setErr('visitors', ''); summary(); });
  $('#minus').onclick = () => { F('visitors').value = Math.max(1, vis() - 1); summary(); }; $('#plus').onclick = () => { F('visitors').value = Math.min(cfg.maxVisitors, vis() + 1); summary(); };
  ['name', 'email', 'phone'].forEach(n => F(n).addEventListener('input', () => setErr(n, '')));
  $('#printBtn').onclick = () => print();
  $('#againBtn').onclick = () => { form.reset(); if (cfg.locations.length === 1) sel.value = cfg.locations[0].id; clearErrs(); $('#doneView').hidden = true; $('#bookingView').hidden = false; loadSlots(); };
  loadSlots();
})();
})();
