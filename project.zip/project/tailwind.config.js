/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: {
          DEFAULT: '#C9A227',
          light: '#E6C65C',
          deep: '#A07A12',
        },
        lapis: {
          DEFAULT: '#1B3A7A',
          deep: '#0F2250',
        },
        faience: {
          DEFAULT: '#2FA79A',
          deep: '#1F7D72',
        },
        carnelian: {
          DEFAULT: '#B5482C',
          deep: '#8C351F',
        },
        sandstone: {
          light: '#E9DFC8',
          DEFAULT: '#D8C7A0',
          deep: '#B9A578',
        },
        kohl: {
          DEFAULT: '#0B0B0F',
          soft: '#15151C',
          panel: '#1B1B24',
        },
        papyrus: {
          DEFAULT: '#6B8E4E',
        },
        ivory: '#F7F2E7',
      },
      fontFamily: {
        en: ['"Playfair Display"', 'Cinzel', 'serif'],
        'en-body': ['Inter', 'system-ui', 'sans-serif'],
        ar: ['"Reem Kufi"', '"Amiri"', 'serif'],
        'ar-body': ['Cairo', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        gold: '0 8px 30px rgba(201, 162, 39, 0.18)',
        'gold-lg': '0 20px 60px rgba(201, 162, 39, 0.22)',
        kohl: '0 20px 50px rgba(0, 0, 0, 0.55)',
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(135deg, #E6C65C 0%, #C9A227 50%, #A07A12 100%)',
        'lapis-gradient': 'linear-gradient(135deg, #1B3A7A 0%, #0F2250 100%)',
        'sandstone-gradient': 'linear-gradient(135deg, #E9DFC8 0%, #D8C7A0 100%)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'ripple': {
          '0%': { transform: 'scale(0)', opacity: '0.6' },
          '100%': { transform: 'scale(4)', opacity: '0' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'slow-zoom': {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.08)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.8s ease-out forwards',
        'fade-in': 'fade-in 0.6s ease-out forwards',
        'scale-in': 'scale-in 0.4s ease-out forwards',
        ripple: 'ripple 0.6s ease-out forwards',
        shimmer: 'shimmer 2.5s linear infinite',
        'slow-zoom': 'slow-zoom 18s ease-in-out infinite alternate',
      },
    },
  },
  plugins: [],
};
