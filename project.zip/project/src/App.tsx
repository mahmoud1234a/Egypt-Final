// src/App.tsx
import { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LanguageProvider, useLanguage } from '@/context/LanguageContext';
import { ThemeProvider } from '@/context/ThemeContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CustomCursor from '@/components/CustomCursor';
import DetailPage from '@/components/DetailPage';

import Home from '@/pages/Home';
import StoryPage from '@/pages/StoryPage';
import GalleriesPage from '@/pages/GalleriesPage';
import ArtifactsPage from '@/pages/ArtifactsPage';
import HoursPage from '@/pages/HoursPage';
import LocationPage from '@/pages/LocationPage';
import NotFound from '@/pages/NotFound';

import { galleries, artifacts } from '@/data/content';

function GalleryDetail() {
  const { t } = useLanguage();
  return <DetailPage items={galleries} categoryLabel={t.galleries.label} backTo="/galleries" backLabel={t.galleries.title} />;
}
function ArtifactDetail() {
  const { t } = useLanguage();
  return <DetailPage items={artifacts} categoryLabel={t.artifacts.label} backTo="/artifacts" backLabel={t.artifacts.title} />;
}

function DocumentTitle() {
  const { isAr } = useLanguage();
  useEffect(() => {
    document.title = isAr ? 'المتحف المصري الكبير – الجيزة' : 'Grand Egyptian Museum – Giza';
  }, [isAr]);
  return null;
}

function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <BrowserRouter>
          <DocumentTitle />
          <CustomCursor />
          <div className="relative flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/story" element={<StoryPage />} />
                <Route path="/galleries" element={<GalleriesPage />} />
                <Route path="/galleries/:slug" element={<GalleryDetail />} />
                <Route path="/artifacts" element={<ArtifactsPage />} />
                <Route path="/artifacts/:slug" element={<ArtifactDetail />} />
                <Route path="/hours" element={<HoursPage />} />
                <Route path="/location" element={<LocationPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </BrowserRouter>
      </LanguageProvider>
    </ThemeProvider>
  );
}

export default App;
