// src/context/LanguageContext.jsx
// Provides 'ar' (default, RTL) or 'en' (LTR). Persists to localStorage.
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import translations from '@/data/translations';

const LanguageContext = createContext();

const STORAGE_KEY = 'gem-lang';

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  });

  const dir = lang === 'ar' ? 'rtl' : 'ltr';
  const isAr = lang === 'ar';
  const t = translations[lang];

  const toggleLang = useCallback(() => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {}
    const html = document.documentElement;
    html.setAttribute('lang', lang);
    html.setAttribute('dir', dir);
  }, [lang, dir]);

  const value = { lang, dir, isAr, t, toggleLang, setLang };
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}

export default LanguageContext;
