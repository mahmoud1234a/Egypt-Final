// src/components/CustomCursor.jsx
// Luxurious gold trailing cursor. Refs only (no re-renders on mousemove).
// Disabled on touch / coarse pointers; respects prefers-reduced-motion.
// Native cursor stays visible — this is an enhancement layered on top.
import { useEffect, useRef } from 'react';
import { useTheme } from '@/context/ThemeContext';

export default function CustomCursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  const glowRef = useRef(null);
  const rippleRef = useRef(null);
  const { isDark } = useTheme();

  useEffect(() => {
    // Only on fine pointers
    const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    if (!fine) return;

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const dot = dotRef.current;
    const ring = ringRef.current;
    const glow = glowRef.current;
    if (!dot || !ring || !glow) return;

    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    const ringPos = { x: target.x, y: target.y };
    const glowPos = { x: target.x, y: target.y };
    let raf = null;
    let visible = false;
    let hovering = false;

    const applyTransforms = () => {
      dot.style.transform = `translate3d(${target.x - 4}px, ${target.y - 4}px, 0)`;
      ring.style.transform = `translate3d(${ringPos.x - 20}px, ${ringPos.y - 20}px, 0) scale(${hovering ? 1.6 : 1})`;
      glow.style.transform = `translate3d(${glowPos.x - 150}px, ${glowPos.y - 150}px, 0)`;
    };

    if (reduced) {
      const onMove = (e) => {
        target.x = e.clientX;
        target.y = e.clientY;
        ringPos.x = e.clientX;
        ringPos.y = e.clientY;
        glowPos.x = e.clientX;
        glowPos.y = e.clientY;
        if (!visible) {
          visible = true;
          dot.style.opacity = '1';
          ring.style.opacity = '1';
        }
        applyTransforms();
      };
      window.addEventListener('mousemove', onMove);
      return () => window.removeEventListener('mousemove', onMove);
    }

    const onMove = (e) => {
      target.x = e.clientX;
      target.y = e.clientY;
      if (!visible) {
        visible = true;
        dot.style.opacity = '1';
        ring.style.opacity = '1';
        glow.style.opacity = isDark ? '0.5' : '0.35';
      }
    };

    const onOver = (e) => {
      const interactive = e.target.closest('a, button, [role="button"], .gem-card-hover, input, textarea, select, label');
      hovering = !!interactive && !e.target.matches('input, textarea, select');
      ring.classList.toggle('cursor-hover', hovering);
      dot.classList.toggle('cursor-hover', hovering);
    };

    const onDown = () => {
      ring.style.transform = `translate3d(${ringPos.x - 20}px, ${ringPos.y - 20}px, 0) scale(1.2)`;
    };
    const onUp = (e) => {
      // ripple
      const r = rippleRef.current;
      if (r) {
        const clone = r.cloneNode(true);
        clone.style.left = e.clientX + 'px';
        clone.style.top = e.clientY + 'px';
        clone.style.opacity = '0.6';
        clone.style.animation = 'ripple 0.6s ease-out forwards';
        document.body.appendChild(clone);
        setTimeout(() => clone.remove(), 650);
      }
    };

    const onLeave = () => {
      visible = false;
      dot.style.opacity = '0';
      ring.style.opacity = '0';
      glow.style.opacity = '0';
    };

    const loop = () => {
      ringPos.x += (target.x - ringPos.x) * 0.15;
      ringPos.y += (target.y - ringPos.y) * 0.15;
      glowPos.x += (target.x - glowPos.x) * 0.08;
      glowPos.y += (target.y - glowPos.y) * 0.08;
      applyTransforms();
      raf = requestAnimationFrame(loop);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseover', onOver);
    window.addEventListener('mousedown', onDown);
    window.addEventListener('mouseup', onUp);
    document.addEventListener('mouseleave', onLeave);
    raf = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseover', onOver);
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('mouseup', onUp);
      document.removeEventListener('mouseleave', onLeave);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [isDark]);

  return (
    <>
      <style>{`
        @media (hover: hover) and (pointer: fine) {
          .gem-cursor-dot,
          .gem-cursor-ring,
          .gem-cursor-glow {
            opacity: 0;
            transition: opacity 0.4s ease, transform 0.12s ease;
          }
          .gem-cursor-dot {
            position: fixed;
            top: 0; left: 0;
            width: 8px; height: 8px;
            border-radius: 9999px;
            background: ${isDark ? '#E6C65C' : '#A07A12'};
            pointer-events: none;
            z-index: 99999;
            will-change: transform;
          }
          .gem-cursor-dot.cursor-hover {
            width: 6px; height: 6px;
            background: #C9A227;
          }
          .gem-cursor-ring {
            position: fixed;
            top: 0; left: 0;
            width: 40px; height: 40px;
            border-radius: 9999px;
            border: 1.5px solid ${isDark ? 'rgba(230,198,92,0.7)' : 'rgba(160,122,18,0.7)'};
            box-shadow: 0 0 24px ${isDark ? 'rgba(230,198,92,0.35)' : 'rgba(201,162,39,0.25)'};
            pointer-events: none;
            z-index: 99998;
            will-change: transform;
            transition: transform 0.18s ease, opacity 0.4s ease, border-color 0.3s ease;
          }
          .gem-cursor-ring.cursor-hover {
            border-color: ${isDark ? '#E6C65C' : '#C9A227'};
            box-shadow: 0 0 32px ${isDark ? 'rgba(230,198,92,0.5)' : 'rgba(201,162,39,0.4)'};
          }
          .gem-cursor-glow {
            position: fixed;
            top: 0; left: 0;
            width: 300px; height: 300px;
            border-radius: 9999px;
            background: radial-gradient(circle, ${isDark ? 'rgba(230,198,92,0.18)' : 'rgba(201,162,39,0.12)'} 0%, transparent 70%);
            pointer-events: none;
            z-index: 1;
            will-change: transform;
            mix-blend-mode: screen;
          }
          .gem-cursor-ripple {
            position: fixed;
            width: 20px; height: 20px;
            margin: -10px 0 0 -10px;
            border-radius: 9999px;
            border: 2px solid #C9A227;
            pointer-events: none;
            z-index: 99997;
          }
        }
        @media (hover: none), (pointer: coarse) {
          .gem-cursor-dot, .gem-cursor-ring, .gem-cursor-glow { display: none !important; }
        }
      `}</style>
      <div ref={glowRef} className="gem-cursor-glow" aria-hidden="true" />
      <div ref={ringRef} className="gem-cursor-ring" aria-hidden="true" />
      <div ref={dotRef} className="gem-cursor-dot" aria-hidden="true" />
      <div ref={rippleRef} className="gem-cursor-ripple" style={{ display: 'none' }} aria-hidden="true" />
    </>
  );
}
