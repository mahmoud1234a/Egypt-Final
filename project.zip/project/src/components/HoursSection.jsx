// src/components/HoursSection.jsx
import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Clock, Ticket, Info, QrCode } from 'lucide-react';
import { openingHours, tickets } from '@/data/content';
import { HieroglyphBorder, Ankh } from './EgyptianPattern';
import TicketBookingModal from './TicketBookingModal';

export default function HoursSection() {
  const { t, isAr } = useLanguage();
  const revealRef = useScrollReveal();
  const [bookingOpen, setBookingOpen] = useState(false);
  const hoursRows = isAr ? openingHours.rowsAr : openingHours.rowsEn;
  const ticketRows = isAr ? tickets.rowsAr : tickets.rowsEn;
  const notes = isAr ? openingHours.notesAr : openingHours.notesEn;

  return (
    <section id="hours" ref={revealRef} className="gem-reveal relative scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-12 text-center">
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.25em] text-gold">{t.hours.label}</p>
          <h2 className="font-heading text-3xl font-bold text-[var(--gem-text)] sm:text-4xl">{t.hours.title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-[var(--gem-text-soft)]">{t.hours.subtitle}</p>
          <HieroglyphBorder className="mx-auto mt-4 h-5 w-40 text-gold opacity-60" />
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Opening hours */}
          <div className="gem-glass rounded-2xl p-6">
            <div className="mb-5 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--gem-gold-soft)] text-gold">
                <Clock className="h-5 w-5" aria-hidden="true" />
              </span>
              <h3 className="font-heading text-xl font-bold text-[var(--gem-text)]">{t.hours.openingTitle}</h3>
            </div>
            <ul className="divide-y divide-[var(--gem-border)]">
              {hoursRows.map((r, i) => (
                <li key={i} className="flex items-center justify-between py-3">
                  <span className="font-medium text-[var(--gem-text)]">{r.day}</span>
                  <span className="text-sm text-[var(--gem-text-soft)]">{r.hours}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 flex items-start gap-2 rounded-xl border border-[var(--gem-border)] bg-[var(--gem-surface-2)] p-3 text-xs text-[var(--gem-text-soft)]">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-faience" aria-hidden="true" />
              <span>{notes}</span>
            </div>
          </div>

          {/* Tickets */}
          <div className="gem-glass rounded-2xl p-6">
            <div className="mb-5 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--gem-gold-soft)] text-gold">
                <Ticket className="h-5 w-5" aria-hidden="true" />
              </span>
              <h3 className="font-heading text-xl font-bold text-[var(--gem-text)]">{t.hours.ticketsTitle}</h3>
            </div>
            <div className="overflow-x-auto gem-scroll-hidden">
              <table className="w-full text-start text-sm">
                <thead>
                  <tr className="border-b border-[var(--gem-border)] text-start">
                    <th className="pb-2 text-start text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.category}</th>
                    <th className="pb-2 text-start text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.price}</th>
                    <th className="pb-2 text-start text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.notes}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--gem-border)]">
                  {ticketRows.map((r, i) => (
                    <tr key={i} className="text-start">
                      <td className="py-3 pe-3 font-medium text-[var(--gem-text)]">{r.category}</td>
                      <td className="py-3 pe-3 text-gold font-semibold">{r.price}</td>
                      <td className="py-3 text-xs text-[var(--gem-text-soft)]">{r.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-5 flex flex-col items-center gap-3">
              <div className="flex items-center gap-2 text-gold">
                <Ankh className="h-5 w-4 opacity-70" />
                <span className="text-xs text-[var(--gem-text-soft)]">{t.hours.booking.poweredBy}</span>
              </div>
              <button
                type="button"
                onClick={() => setBookingOpen(true)}
                className="inline-flex items-center gap-2 rounded-full gem-btn-gold px-6 py-3 text-sm font-semibold shadow-gold"
              >
                <QrCode className="h-4 w-4" aria-hidden="true" />
                {t.hours.book}
              </button>
            </div>
          </div>
        </div>
      </div>

      <TicketBookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </section>
  );
}
