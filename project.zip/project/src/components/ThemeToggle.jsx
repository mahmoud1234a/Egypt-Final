// src/components/ThemeToggle.jsx
import { useTheme } from '@/context/ThemeContext';
import { useLanguage } from '@/context/LanguageContext';
import { Sun, Moon } from 'lucide-react';

export default function ThemeToggle({ className = '' }) {
  const { isDark, toggleTheme, theme } = useTheme();
  const { t } = useLanguage();
  const label = isDark ? t.themeToggleToLight : t.themeToggleToDark;
  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={label}
      title={label}
      className={`group inline-flex h-9 w-9 items-center justify-center rounded-full border border-[var(--gem-border-strong)] transition-all hover:bg-[var(--gem-gold-soft)] hover:-translate-y-0.5 ${className}`}
    >
      {isDark ? (
        <Sun className="h-5 w-5 text-gold-light" aria-hidden="true" />
      ) : (
        <Moon className="h-5 w-5 text-lapis" aria-hidden="true" />
      )}
      <span className="sr-only">{theme}</span>
    </button>
  );
}
