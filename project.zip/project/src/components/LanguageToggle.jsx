// src/components/LanguageToggle.jsx
import { useLanguage } from '@/context/LanguageContext';
import { Languages } from 'lucide-react';

export default function LanguageToggle({ className = '' }) {
  const { lang, toggleLang, t } = useLanguage();
  return (
    <button
      type="button"
      onClick={toggleLang}
      aria-label={t.langToggleAria}
      title={t.langToggleAria}
      className={`group inline-flex items-center gap-1.5 rounded-full border border-[var(--gem-border-strong)] px-3 py-1.5 text-sm font-semibold transition-all hover:bg-[var(--gem-gold-soft)] hover:-translate-y-0.5 ${className}`}
    >
      <Languages className="h-4 w-4 text-gold" aria-hidden="true" />
      <span className="font-heading">{t.langToggleLabel}</span>
    </button>
  );
}
