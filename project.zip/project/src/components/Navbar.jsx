// src/components/Navbar.jsx
// Sticky glass navbar. Logo + links (desktop) / drawer (mobile).
// Language + Theme toggles always visible beside hamburger on mobile.
import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { Menu, X } from 'lucide-react';
import LanguageToggle from './LanguageToggle';
import ThemeToggle from './ThemeToggle';
import { PyramidMotif, WingedSunDisk } from './EgyptianPattern';

export default function Navbar() {
  const { t, isAr } = useLanguage();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  const links = [
    { to: '/story', label: t.nav.story },
    { to: '/galleries', label: t.nav.galleries },
    { to: '/artifacts', label: t.nav.artifacts },
    { to: '/hours', label: t.nav.hours },
    { to: '/location', label: t.nav.location },
  ];

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[1000] transition-all duration-500 ${
        scrolled ? 'py-2' : 'py-4'
      }`}
    >
      <nav
        className={`mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 transition-all duration-500 ${
          scrolled ? 'gem-glass rounded-full mx-3 sm:mx-auto py-2.5 shadow-gold' : 'py-1'
        }`}
        aria-label={isAr ? 'التنقل' : 'Navigation'}
      >
        {/* Logo */}
        <Link to="/" className="group flex items-center gap-2.5" aria-label={t.museumName}>
          <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/50 bg-[var(--gem-gold-soft)] transition-transform group-hover:scale-105">
            <PyramidMotif className="h-6 w-6 text-gold" />
          </span>
          <span className="hidden flex-col leading-tight sm:flex">
            <span className="font-heading text-base font-bold text-[var(--gem-text)]">{t.museumName}</span>
            <span className="text-[10px] tracking-wider text-gold uppercase">{t.locationNote}</span>
          </span>
        </Link>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <li key={l.to}>
              <NavLink
                to={l.to}
                className={({ isActive }) =>
                  `gem-link rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                    isActive ? 'text-gold' : 'text-[var(--gem-text-soft)] hover:text-gold'
                  }`
                }
              >
                {l.label}
              </NavLink>
            </li>
          ))}
        </ul>

        {/* Right cluster */}
        <div className="flex items-center gap-2">
          <LanguageToggle />
          <ThemeToggle />
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? t.closeMenu : t.openMenu}
            aria-expanded={open}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[var(--gem-border-strong)] text-[var(--gem-text)] transition-all hover:bg-[var(--gem-gold-soft)] lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      {open && (
        <div className="mx-3 mt-2 lg:hidden animate-fade-in">
          <div className="gem-glass rounded-2xl p-4">
            <div className="mb-3 flex items-center justify-center">
              <WingedSunDisk className="h-5 w-20 text-gold opacity-70" />
            </div>
            <ul className="flex flex-col gap-1">
              {links.map((l) => (
                <li key={l.to}>
                  <NavLink
                    to={l.to}
                    className={({ isActive }) =>
                      `block rounded-xl px-4 py-3 text-base font-medium transition-colors ${
                        isActive ? 'bg-[var(--gem-gold-soft)] text-gold' : 'text-[var(--gem-text)] hover:bg-[var(--gem-gold-soft)]'
                      }`
                    }
                  >
                    {l.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </header>
  );
}
