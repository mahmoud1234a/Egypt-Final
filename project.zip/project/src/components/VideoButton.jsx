// src/components/VideoButton.jsx
// A button that opens the VideoModal for a given content item.
// Used on cards and detail pages.
import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { Play } from 'lucide-react';
import VideoModal from './VideoModal';

export default function VideoButton({ video, poster, titleAr, titleEn, label, className = '', iconOnly = false }) {
  const { t, isAr } = useLanguage();
  const [open, setOpen] = useState(false);
  const text = label || t.detail.watchVideo;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={`group inline-flex items-center justify-center gap-2 rounded-full gem-btn-gold px-5 py-2.5 text-sm transition-all ${className}`}
        aria-label={isAr ? `شاهد الفيديو: ${titleAr}` : `Watch video: ${titleEn}`}
      >
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-kohl/20 transition-transform group-hover:scale-110">
          <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
        </span>
        {!iconOnly && <span className="font-heading">{text}</span>}
      </button>
      <VideoModal
        open={open}
        onClose={() => setOpen(false)}
        videoSrc={video}
        poster={poster}
        titleAr={titleAr}
        titleEn={titleEn}
      />
    </>
  );
}
