// src/components/ItemCard.jsx
// Reusable card for galleries & artifacts: poster, title, description,
// "Watch Video" button, and "Explore" link to detail page.
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { ArrowUpRight, ArrowLeft, ArrowRight } from 'lucide-react';
import SmartImage from './SmartImage';
import VideoButton from './VideoButton';

export default function ItemCard({ item, exploreTo, exploreLabel }) {
  const { isAr, t } = useLanguage();
  const title = isAr ? item.titleAr : item.titleEn;
  const desc = isAr ? item.descriptionAr : item.descriptionEn;
  const Arrow = isAr ? ArrowLeft : ArrowRight;

  return (
    <article className="gem-card-hover group flex flex-col overflow-hidden rounded-2xl gem-glass transition-all duration-500 hover:-translate-y-1.5 hover:shadow-gold-lg">
      {/* Poster */}
      <Link to={exploreTo} className="relative block aspect-[4/3] overflow-hidden" aria-label={title}>
        <SmartImage
          src={item.poster}
          alt={title}
          titleAr={item.titleAr}
          titleEn={item.titleEn}
          rounded={false}
          className="h-full w-full"
          imgClassName="transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-kohl/70 via-transparent to-transparent opacity-80" aria-hidden="true" />
        <div className="absolute inset-x-0 bottom-0 p-4">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-kohl/40 px-3 py-1 text-xs font-medium text-gold-light backdrop-blur-sm">
            <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            {exploreLabel}
          </span>
        </div>
      </Link>

      {/* Body */}
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-heading text-xl font-bold text-[var(--gem-text)] transition-colors group-hover:text-gold">{title}</h3>
        <p className="mt-2 line-clamp-3 flex-1 text-sm leading-relaxed text-[var(--gem-text-soft)]">{desc}</p>

        <div className="mt-5 flex items-center justify-between gap-3">
          <VideoButton
            video={item.video}
            poster={item.poster}
            titleAr={item.titleAr}
            titleEn={item.titleEn}
            label={t.galleries.watch}
            className="px-4 py-2 text-xs"
          />
          <Link
            to={exploreTo}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-gold transition-colors hover:text-gold-light"
          >
            {t.detail.back === 'رجوع' ? 'استكشف' : 'Explore'}
            <Arrow className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </article>
  );
}
