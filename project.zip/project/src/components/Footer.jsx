// src/components/Footer.jsx
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { Phone, Mail, MapPin, Download } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import { PyramidMotif, WingedSunDisk, HieroglyphBorder } from './EgyptianPattern';
import { contact } from '@/data/content';

export default function Footer() {
  const { t, isAr } = useLanguage();

  const links = [
    { to: '/story', label: t.nav.story },
    { to: '/galleries', label: t.nav.galleries },
    { to: '/artifacts', label: t.nav.artifacts },
    { to: '/hours', label: t.nav.hours },
    { to: '/location', label: t.nav.location },
  ];

  const siteUrl = typeof window !== 'undefined' ? window.location.origin : 'https://grandegyptianmuseum.org';

  const downloadQr = () => {
    const canvas = document.getElementById('gem-site-qr');
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = 'GEM-website-qr.png';
    a.click();
  };

  return (
    <footer className="relative mt-20 overflow-hidden border-t border-[var(--gem-border)] bg-[var(--gem-bg-alt)]">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
      <HieroglyphBorder className="mt-2 h-5 w-full text-gold opacity-40" />

      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* About */}
          <div>
            <div className="mb-4 flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/50 bg-[var(--gem-gold-soft)]">
                <PyramidMotif className="h-6 w-6 text-gold" />
              </span>
              <span className="font-heading text-lg font-bold text-[var(--gem-text)]">{t.museumName}</span>
            </div>
            <p className="text-sm leading-relaxed text-[var(--gem-text-soft)]">{t.footer.about}: {t.tagline}</p>
            <p className="mt-3 text-xs leading-relaxed text-[var(--gem-text-soft)]/70">{t.footer.disclaimer}</p>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="mb-4 font-heading text-sm font-semibold uppercase tracking-wider text-gold">{t.footer.quickLinks}</h4>
            <ul className="space-y-2">
              {links.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="gem-link text-sm text-[var(--gem-text-soft)]">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="mb-4 font-heading text-sm font-semibold uppercase tracking-wider text-gold">{t.footer.contact}</h4>
            <ul className="space-y-3 text-sm text-[var(--gem-text-soft)]">
              <li className="flex items-start gap-2.5">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
                <span><span className="block text-xs text-gold/80">{t.footer.phone}</span>{contact.phone}</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
                <span><span className="block text-xs text-gold/80">{t.footer.email}</span>{contact.email}</span>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
                <span><span className="block text-xs text-gold/80">{t.footer.address}</span>{isAr ? contact.addressAr : contact.addressEn}</span>
              </li>
            </ul>
          </div>

          {/* Site QR code */}
          <div className="flex flex-col items-center text-center">
            <h4 className="mb-4 font-heading text-sm font-semibold uppercase tracking-wider text-gold">{t.footer.siteQr}</h4>
            <div className="rounded-2xl border border-gold/40 bg-white p-3 shadow-gold">
              <QRCodeCanvas
                id="gem-site-qr"
                value={siteUrl}
                size={132}
                level="M"
                fgColor="#0F2250"
                bgColor="#ffffff"
              />
            </div>
            <p className="mt-3 max-w-[14rem] text-xs leading-relaxed text-[var(--gem-text-soft)]">{t.footer.siteQrDesc}</p>
            <button
              type="button"
              onClick={downloadQr}
              className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-[var(--gem-border-strong)] px-4 py-2 text-xs font-semibold text-[var(--gem-text)] transition-all hover:bg-[var(--gem-gold-soft)] hover:-translate-y-0.5"
              aria-label={isAr ? 'تحميل باركود الموقع' : 'Download site QR code'}
            >
              <Download className="h-3.5 w-3.5 text-gold" aria-hidden="true" />
              {isAr ? 'تحميل الباركود' : 'Download QR'}
            </button>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center gap-3 border-t border-[var(--gem-border)] pt-6 text-center">
          <WingedSunDisk className="h-5 w-24 text-gold opacity-60" />
          <p className="text-xs text-[var(--gem-text-soft)]">
            © {new Date().getFullYear()} {t.museumName} — {t.footer.rights}
          </p>
        </div>
      </div>
    </footer>
  );
}
