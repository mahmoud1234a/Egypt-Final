// src/components/VideoModal.jsx
// Accessible video modal: closes with X, Esc, backdrop click; pauses on close.
// Missing video -> friendly bilingual "coming soon" message.
import { useEffect, useRef, useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { X } from 'lucide-react';

export default function VideoModal({ open, onClose, videoSrc, poster, titleAr, titleEn }) {
  const { isAr, t } = useLanguage();
  const videoRef = useRef(null);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    if (!open) return;
    setHasError(false);
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (open) {
      v.load();
      v.play().catch(() => {});
    } else {
      v.pause();
    }
  }, [open]);

  useEffect(() => {
    setHasError(false);
  }, [videoSrc]);

  if (!open) return null;

  const title = isAr ? titleAr : titleEn;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div
      className="fixed inset-0 z-[2000] flex items-center justify-center p-4 sm:p-6 animate-fade-in"
      onClick={handleBackdropClick}
      role="dialog"
      aria-modal="true"
      aria-label={title || t.video.title}
    >
      <div className="absolute inset-0 bg-kohl/85 backdrop-blur-md" aria-hidden="true" />

      <div className="relative z-10 w-full max-w-4xl animate-scale-in">
        <div className="gem-glass gem-gold-border overflow-hidden rounded-2xl">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[var(--gem-border)] px-5 py-3">
            <h3 className="font-heading text-lg font-semibold text-gold truncate">{title}</h3>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.video.close}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[var(--gem-border)] text-[var(--gem-text-soft)] transition-all hover:bg-[var(--gem-gold-soft)] hover:text-gold"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>

          {/* Body */}
          <div className="relative bg-kohl">
            {videoSrc && !hasError ? (
              <video
                ref={videoRef}
                src={videoSrc}
                poster={poster}
                controls
                playsInline
                onError={() => setHasError(true)}
                className="aspect-video w-full bg-kohl"
              >
                <track kind="captions" />
              </video>
            ) : (
              <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-lapis-deep via-kohl to-lapis p-8 text-center">
                <svg viewBox="0 0 64 64" className="h-14 w-14 text-gold-light opacity-80" fill="none" aria-hidden="true">
                  <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="2" />
                  <path d="M26 22 L44 32 L26 42 Z" fill="currentColor" />
                </svg>
                <p className="font-heading text-xl font-semibold text-gold-light">{t.video.comingSoon}</p>
                <p className="max-w-sm text-sm text-sandstone-light/80">{t.video.comingSoonDesc}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
