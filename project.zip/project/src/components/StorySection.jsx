// src/components/StorySection.jsx
// The Story section (also on home). Poster + text + watch button + facts strip.
// Full story lives at /story (StoryPage).
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { ArrowRight, ArrowLeft, BookOpen } from 'lucide-react';
import { story } from '@/data/content';
import SmartImage from './SmartImage';
import VideoButton from './VideoButton';
import { HieroglyphBorder, EyeOfHorus } from './EgyptianPattern';

export default function StorySection() {
  const { t, isAr } = useLanguage();
  const revealRef = useScrollReveal();
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  const title = isAr ? story.titleAr : story.titleEn;
  const paragraphs = isAr ? story.paragraphsAr : story.paragraphsEn;
  const facts = isAr ? story.factsAr : story.factsEn;
  const introParagraph = paragraphs[0];

  return (
    <section id="story" ref={revealRef} className="gem-reveal relative scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12 text-center">
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.25em] text-gold">{t.story.label}</p>
          <h2 className="font-heading text-3xl font-bold text-[var(--gem-text)] sm:text-4xl">{t.story.title}</h2>
          <HieroglyphBorder className="mx-auto mt-4 h-5 w-40 text-gold opacity-60" />
        </div>

        <div className="grid items-center gap-10 lg:grid-cols-2">
          {/* Poster */}
          <div className="relative order-2 lg:order-1">
            <div className="absolute -inset-3 rounded-3xl border border-gold/20 opacity-60" aria-hidden="true" />
            <SmartImage
              src={story.poster}
              alt={title}
              titleAr={story.titleAr}
              titleEn={story.titleEn}
              className="aspect-[4/3] w-full shadow-kohl"
            />
            <div className="absolute bottom-4 flex items-center gap-3 px-4">
              <VideoButton
                video={story.video}
                poster={story.poster}
                titleAr={story.titleAr}
                titleEn={story.titleEn}
                label={t.story.watch}
                className="shadow-gold-lg"
              />
            </div>
          </div>

          {/* Text */}
          <div className="order-1 lg:order-2">
            <div className="mb-5 flex items-center gap-2 text-gold">
              <EyeOfHorus className="h-5 w-7" />
              <span className="text-xs font-semibold uppercase tracking-widest">{t.story.label}</span>
            </div>
            <h3 className="font-heading text-2xl font-bold text-[var(--gem-text)] sm:text-3xl">{title}</h3>
            <p className="mt-5 text-base leading-[1.9] text-[var(--gem-text-soft)]">{introParagraph}</p>

            {/* Facts strip */}
            <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {facts.map((f, i) => (
                <div key={i} className="rounded-xl border border-[var(--gem-border)] bg-[var(--gem-surface)] p-3 text-center">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-gold/80">{f.label}</p>
                  <p className="mt-1 text-sm font-medium text-[var(--gem-text)]">{f.value}</p>
                </div>
              ))}
            </div>

            <Link
              to="/story"
              className="mt-8 inline-flex items-center gap-2 rounded-full gem-btn-outline px-6 py-3 text-sm font-semibold"
            >
              {t.story.learnMore}
              <Arrow className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
