// src/components/DetailPage.jsx
// Shared detail page for a gallery or artifact item.
// Shows hero poster, title, full description, video button, and prev/next nav.
import { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { ArrowRight, ArrowLeft, ChevronRight, ChevronLeft } from 'lucide-react';
import SmartImage from './SmartImage';
import VideoButton from './VideoButton';
import { HieroglyphBorder, PyramidBand, EyeOfHorus } from './EgyptianPattern';

export default function DetailPage({ items, categoryLabel, backTo, backLabel }) {
  const { slug } = useParams();
  const { t, isAr } = useLanguage();
  const navigate = useNavigate();
  const revealRef = useScrollReveal();

  const index = items.findIndex((i) => i.slug === slug);
  const item = index !== -1 ? items[index] : null;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [slug]);

  if (!item) {
    return (
      <div className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center">
        <p className="font-heading text-2xl text-[var(--gem-text)]">{isAr ? 'لم يتم العثور على الصفحة' : 'Page not found'}</p>
        <Link to={backTo} className="mt-4 gem-btn-outline rounded-full px-6 py-3 text-sm font-semibold">{t.detail.back}</Link>
      </div>
    );
  }

  const prev = items[(index - 1 + items.length) % items.length];
  const next = items[(index + 1) % items.length];
  const title = isAr ? item.titleAr : item.titleEn;
  const desc = isAr ? item.descriptionAr : item.descriptionEn;
  const PrevArrow = isAr ? ChevronLeft : ChevronRight;
  const NextArrow = isAr ? ChevronRight : ChevronLeft;
  const prevLabel = t.detail.prevItem;
  const nextLabel = t.detail.nextItem;

  const go = (path) => () => navigate(path);

  return (
    <article className="pt-24">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="relative h-[55vh] min-h-[360px] w-full">
          <SmartImage
            src={item.poster}
            alt={title}
            titleAr={item.titleAr}
            titleEn={item.titleEn}
            rounded={false}
            className="h-full w-full"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-kohl via-kohl/40 to-kohl/30" aria-hidden="true" />
          <div className="absolute inset-0 bg-gradient-to-b from-kohl/60 via-transparent to-transparent" aria-hidden="true" />
          <PyramidBand className="absolute bottom-0 left-0 h-14 w-full text-gold opacity-25" />
        </div>

        <div className="absolute inset-x-0 bottom-0 p-6 sm:p-10">
          <div className="mx-auto max-w-5xl">
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.3em] text-gold-light">{categoryLabel}</p>
            <h1 className="font-heading text-3xl font-black text-sandstone-light sm:text-5xl">{title}</h1>
          </div>
        </div>
      </section>

      {/* Body */}
      <section ref={revealRef} className="gem-reveal relative py-14">
        <div className="mx-auto max-w-5xl px-6">
          {/* Breadcrumb / back */}
          <div className="mb-8 flex items-center gap-2 text-sm text-[var(--gem-text-soft)]">
            <Link to="/" className="gem-link">{t.nav.home}</Link>
            <ChevronRight className={`h-4 w-4 ${isAr ? 'rotate-180' : ''}`} aria-hidden="true" />
            <Link to={backTo} className="gem-link">{backLabel}</Link>
            <ChevronRight className={`h-4 w-4 ${isAr ? 'rotate-180' : ''}`} aria-hidden="true" />
            <span className="text-gold">{title}</span>
          </div>

          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="mb-4 flex items-center gap-2 text-gold">
                <EyeOfHorus className="h-5 w-7" />
                <span className="text-xs font-semibold uppercase tracking-widest">{categoryLabel}</span>
              </div>
              <h2 className="font-heading text-2xl font-bold text-[var(--gem-text)] sm:text-3xl">{title}</h2>
              <HieroglyphBorder className="mt-3 h-5 w-32 text-gold opacity-50" />
              <p className="mt-6 text-base leading-[2] text-[var(--gem-text-soft)] sm:text-lg">{desc}</p>
            </div>

            <aside className="lg:col-span-1">
              <div className="sticky top-28 gem-glass rounded-2xl p-6 text-center">
                <SmartImage
                  src={item.poster}
                  alt={title}
                  titleAr={item.titleAr}
                  titleEn={item.titleEn}
                  className="aspect-video w-full mb-5"
                />
                <VideoButton
                  video={item.video}
                  poster={item.poster}
                  titleAr={item.titleAr}
                  titleEn={item.titleEn}
                  label={t.detail.watchVideo}
                  className="w-full"
                />
              </div>
            </aside>
          </div>

          {/* Prev / Next nav */}
          <nav className="mt-12 grid gap-4 border-t border-[var(--gem-border)] pt-8 sm:grid-cols-2" aria-label={isAr ? 'التنقل بين العناصر' : 'Item navigation'}>
            <button
              type="button"
              onClick={go(`/${backTo.replace(/^\//, '')}/${prev.slug}`)}
              className="group flex items-center gap-3 rounded-2xl border border-[var(--gem-border)] p-4 text-start transition-all hover:bg-[var(--gem-gold-soft)]"
              aria-label={prevLabel}
            >
              <PrevArrow className="h-5 w-5 shrink-0 text-gold" aria-hidden="true" />
              <span className="min-w-0">
                <span className="block text-[11px] uppercase tracking-wide text-gold/80">{t.detail.prev}</span>
                <span className="block truncate font-heading text-sm font-semibold text-[var(--gem-text)]">{isAr ? prev.titleAr : prev.titleEn}</span>
              </span>
            </button>
            <button
              type="button"
              onClick={go(`/${backTo.replace(/^\//, '')}/${next.slug}`)}
              className="group flex items-center justify-end gap-3 rounded-2xl border border-[var(--gem-border)] p-4 text-end transition-all hover:bg-[var(--gem-gold-soft)] sm:order-last"
              aria-label={nextLabel}
            >
              <span className="min-w-0">
                <span className="block text-[11px] uppercase tracking-wide text-gold/80">{t.detail.next}</span>
                <span className="block truncate font-heading text-sm font-semibold text-[var(--gem-text)]">{isAr ? next.titleAr : next.titleEn}</span>
              </span>
              <NextArrow className="h-5 w-5 shrink-0 text-gold" aria-hidden="true" />
            </button>
          </nav>

          <div className="mt-10 text-center">
            <Link to={backTo} className="inline-flex items-center gap-2 text-sm font-semibold text-gold hover:text-gold-light">
              <ArrowLeft className={`h-4 w-4 ${isAr ? '' : 'rotate-180'}`} aria-hidden="true" />
              {backLabel}
            </Link>
          </div>
        </div>
      </section>
    </article>
  );
}
