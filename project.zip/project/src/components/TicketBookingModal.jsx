// src/components/TicketBookingModal.jsx
// Ticket booking flow with a generated QR code (demo — no backend).
// Visitor selects category, quantity, name, email, and date, then
// receives a QR code encoding the booking details to show at the gate.
import { useEffect, useMemo, useState } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { useLanguage } from '@/context/LanguageContext';
import { tickets } from '@/data/content';
import { X, Ticket, Check, Calendar, User, Mail, Minus, Plus, Download } from 'lucide-react';
import { WingedSunDisk, PyramidMotif } from './EgyptianPattern';

export default function TicketBookingModal({ open, onClose }) {
  const { isAr, t } = useLanguage();
  const ticketRows = isAr ? tickets.rowsAr : tickets.rowsEn;

  const [selected, setSelected] = useState('');
  const [qty, setQty] = useState(1);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  const [ticketNo, setTicketNo] = useState('');

  useEffect(() => {
    if (open) {
      setDone(false);
      setError('');
    } else {
      // reset after close
      const id = setTimeout(() => {
        setSelected('');
        setQty(1);
        setName('');
        setEmail('');
        setDate('');
        setError('');
        setDone(false);
      }, 300);
      return () => clearTimeout(id);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  const chosen = ticketRows.find((r) => r.category === selected);
  const isFree = chosen && (isAr ? chosen.price === 'مجاناً' : chosen.price === 'Free');

  // Extract numeric price for total display when not free / not placeholder
  const unitPrice = useMemo(() => {
    if (!chosen || isFree) return 0;
    const m = String(chosen.price).match(/[\d,]+/);
    return m ? parseFloat(m[0].replace(/,/g, '')) : 0;
  }, [chosen, isFree]);

  const totalLabel = useMemo(() => {
    if (!chosen) return '';
    if (isFree) return t.hours.booking.free;
    if (unitPrice > 0) return `${(unitPrice * qty).toLocaleString(isAr ? 'ar-EG' : 'en-US')} ${isAr ? 'ج.م' : 'EGP'}`;
    return chosen.price;
  }, [chosen, isFree, unitPrice, qty, isAr, t]);

  const validate = () => {
    if (!selected) return t.hours.booking.chooseCategory;
    if (!name.trim()) return t.hours.booking.enterName;
    if (!email.trim()) return t.hours.booking.enterEmail;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return t.hours.booking.invalidEmail;
    if (!date) return isAr ? 'من فضلك اختر تاريخ الزيارة' : 'Please choose a visit date';
    return '';
  };

  const confirm = () => {
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setError('');
    setTicketNo('GEM-' + Date.now().toString(36).toUpperCase().slice(-8));
    setDone(true);
  };

  // QR payload
  const qrPayload = useMemo(() => {
    const payload = {
      museum: 'Grand Egyptian Museum — Giza',
      ticket: ticketNo,
      category: selected,
      quantity: qty,
      name,
      email,
      date,
      total: totalLabel,
    };
    return JSON.stringify(payload);
  }, [ticketNo, selected, qty, name, email, date, totalLabel]);

  const downloadQr = () => {
    const canvas = document.getElementById('gem-qr-canvas');
    if (!canvas) return;
    const pngUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = pngUrl;
    a.download = `GEM-ticket-${ticketNo}.png`;
    a.click();
  };

  const backdropClick = (e) => e.target === e.currentTarget && onClose();

  const inputCls =
    'w-full rounded-xl border border-[var(--gem-border)] bg-[var(--gem-surface-2)] px-4 py-3 text-sm text-[var(--gem-text)] placeholder:text-[var(--gem-text-soft)]/60 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold/40 transition-colors';

  return (
    <div
      className="fixed inset-0 z-[2100] flex items-center justify-center p-4 animate-fade-in"
      onClick={backdropClick}
      role="dialog"
      aria-modal="true"
      aria-label={t.hours.booking.title}
    >
      <div className="absolute inset-0 bg-kohl/85 backdrop-blur-md" aria-hidden="true" />

      <div className="relative z-10 w-full max-w-lg max-h-[92vh] overflow-y-auto gem-scroll-hidden animate-scale-in">
        <div className="gem-glass gem-gold-border overflow-hidden rounded-2xl">
          {/* Header */}
          <div className="relative border-b border-[var(--gem-border)] px-5 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--gem-gold-soft)] text-gold">
                  <Ticket className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="font-heading text-lg font-bold text-[var(--gem-text)]">{t.hours.booking.title}</h3>
                  <p className="text-xs text-[var(--gem-text-soft)]">{t.hours.booking.subtitle}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label={t.hours.booking.close}
                className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[var(--gem-border)] text-[var(--gem-text-soft)] transition-all hover:bg-[var(--gem-gold-soft)] hover:text-gold"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
            <WingedSunDisk className="absolute end-3 bottom-2 h-4 w-16 text-gold opacity-20" />
          </div>

          {/* Body */}
          <div className="p-5">
            {!done ? (
              <div className="space-y-5">
                {/* Category */}
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.booking.category}</label>
                  <div className="grid gap-2 max-h-52 overflow-y-auto gem-scroll-hidden pe-1">
                    {ticketRows.map((r) => (
                      <button
                        type="button"
                        key={r.category}
                        onClick={() => setSelected(r.category)}
                        className={`flex items-center justify-between rounded-xl border px-4 py-3 text-start text-sm transition-all ${
                          selected === r.category
                            ? 'border-gold bg-[var(--gem-gold-soft)] text-[var(--gem-text)]'
                            : 'border-[var(--gem-border)] text-[var(--gem-text-soft)] hover:border-gold/50 hover:bg-[var(--gem-gold-soft)]/50'
                        }`}
                      >
                        <span className="font-medium">{r.category}</span>
                        <span className="text-gold font-semibold">{r.price}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quantity */}
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.booking.quantity}</label>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[var(--gem-border-strong)] text-gold transition-all hover:bg-[var(--gem-gold-soft)]"
                      aria-label={t.detail.prev}
                    >
                      <Minus className="h-4 w-4" aria-hidden="true" />
                    </button>
                    <span className="w-12 text-center font-heading text-xl font-bold text-[var(--gem-text)]">{qty}</span>
                    <button
                      type="button"
                      onClick={() => setQty((q) => Math.min(10, q + 1))}
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[var(--gem-border-strong)] text-gold transition-all hover:bg-[var(--gem-gold-soft)]"
                      aria-label={t.detail.next}
                    >
                      <Plus className="h-4 w-4" aria-hidden="true" />
                    </button>
                    <span className="ms-2 text-xs text-[var(--gem-text-soft)]">
                      {t.hours.booking.bookingFor} {qty} {qty === 1 ? t.hours.booking.person : t.hours.booking.people}
                    </span>
                  </div>
                </div>

                {/* Name */}
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.booking.name}</label>
                  <div className="relative">
                    <User className="pointer-events-none absolute inset-inline-start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gold/60" aria-hidden="true" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={t.hours.booking.namePlaceholder}
                      className={`${inputCls} ps-11`}
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.booking.email}</label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute inset-inline-start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gold/60" aria-hidden="true" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={t.hours.booking.emailPlaceholder}
                      className={`${inputCls} ps-11`}
                      dir="ltr"
                    />
                  </div>
                </div>

                {/* Date */}
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gold/80">{t.hours.booking.date}</label>
                  <div className="relative">
                    <Calendar className="pointer-events-none absolute inset-inline-start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gold/60" aria-hidden="true" />
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className={`${inputCls} ps-11`}
                    />
                  </div>
                </div>

                {/* Total */}
                {chosen && (
                  <div className="flex items-center justify-between rounded-xl border border-gold/30 bg-[var(--gem-gold-soft)] px-4 py-3">
                    <span className="text-sm font-semibold text-[var(--gem-text)]">{t.hours.booking.total}</span>
                    <span className="font-heading text-xl font-bold text-gold">{totalLabel}</span>
                  </div>
                )}

                {error && (
                  <p className="rounded-xl border border-carnelian/40 bg-carnelian/10 px-4 py-2.5 text-sm text-carnelian">
                    {error}
                  </p>
                )}

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 rounded-full gem-btn-outline px-5 py-3 text-sm font-semibold"
                  >
                    {t.hours.booking.cancel}
                  </button>
                  <button
                    type="button"
                    onClick={confirm}
                    className="flex-1 rounded-full gem-btn-gold px-5 py-3 text-sm font-semibold"
                  >
                    {t.hours.booking.confirm}
                  </button>
                </div>
              </div>
            ) : (
              /* Success screen with QR code */
              <div className="py-2 text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-faience/20 text-faience">
                  <Check className="h-7 w-7" aria-hidden="true" />
                </div>
                <h3 className="font-heading text-xl font-bold text-[var(--gem-text)]">{t.hours.booking.success}</h3>
                <p className="mt-2 text-sm text-[var(--gem-text-soft)]">{t.hours.booking.successDesc}</p>

                {/* QR card */}
                <div className="mx-auto mt-6 max-w-xs rounded-2xl border border-gold/40 bg-[var(--gem-surface-2)] p-5">
                  <div className="mb-3 flex justify-center">
                    <PyramidMotif className="h-6 w-6 text-gold" />
                  </div>
                  <div className="flex justify-center rounded-xl bg-white p-3">
                    <QRCodeCanvas
                      id="gem-qr-canvas"
                      value={qrPayload}
                      size={180}
                      level="M"
                      includeMargin={false}
                      fgColor="#0F2250"
                      bgColor="#ffffff"
                    />
                  </div>
                  <div className="mt-4 space-y-1 text-start text-xs text-[var(--gem-text-soft)]">
                    <p className="flex justify-between"><span>{t.hours.booking.ticketNo}</span><span className="font-mono text-gold">{ticketNo}</span></p>
                    <p className="flex justify-between"><span>{t.hours.booking.category}</span><span>{selected}</span></p>
                    <p className="flex justify-between"><span>{t.hours.booking.quantity}</span><span>{qty}</span></p>
                    <p className="flex justify-between"><span>{t.hours.booking.visitDate}</span><span>{date}</span></p>
                    <p className="flex justify-between"><span>{t.hours.booking.total}</span><span className="font-semibold text-gold">{totalLabel}</span></p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={downloadQr}
                  className="mt-5 inline-flex items-center gap-2 rounded-full gem-btn-gold px-5 py-2.5 text-sm font-semibold"
                >
                  <Download className="h-4 w-4" aria-hidden="true" />
                  {t.hours.booking.download}
                </button>

                <p className="mt-4 text-[11px] text-[var(--gem-text-soft)]/60">{t.hours.booking.poweredBy}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
