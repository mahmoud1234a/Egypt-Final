// src/components/SmartImage.jsx
// <img> with graceful fallback: if the src fails to load, shows a styled
// gradient block with the item title. Used for posters.
import { useEffect, useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';

export default function SmartImage({ src, alt, titleAr, titleEn, className = '', imgClassName = '', rounded = true }) {
  const { isAr } = useLanguage();
  const [errored, setErrored] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setErrored(false);
    setLoaded(false);
  }, [src]);

  const fallbackTitle = isAr ? titleAr : titleEn;

  if (errored || !src) {
    return (
      <div
        className={`gem-img-fallback flex items-center justify-center p-8 text-center ${rounded ? 'rounded-2xl' : ''} ${className}`}
        role="img"
        aria-label={alt}
      >
        <div>
          <div className="mb-3 flex justify-center opacity-70">
            <svg viewBox="0 0 64 64" className="h-12 w-12 text-gold-light" fill="none" aria-hidden="true">
              <path d="M32 8 L56 56 L8 56 Z" stroke="currentColor" strokeWidth="2" />
              <path d="M32 24 L44 48 L20 48 Z" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
            </svg>
          </div>
          <span className="block font-heading text-lg font-semibold text-sandstone-light drop-shadow">
            {fallbackTitle}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${rounded ? 'rounded-2xl' : ''} ${className}`}>
      {!loaded && (
        <div className="absolute inset-0 gem-img-fallback animate-pulse" aria-hidden="true" />
      )}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        onError={() => setErrored(true)}
        className={`h-full w-full object-cover ${imgClassName} ${loaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-700`}
      />
    </div>
  );
}
