// src/components/LocationSection.jsx
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { MapPin, Navigation } from 'lucide-react';
import { contact } from '@/data/content';
import { HieroglyphBorder, Obelisk } from './EgyptianPattern';

export default function LocationSection() {
  const { t, isAr } = useLanguage();
  const revealRef = useScrollReveal();
  const address = isAr ? contact.addressAr : contact.addressEn;

  return (
    <section id="location" ref={revealRef} className="gem-reveal relative scroll-mt-24 py-20 sm:py-28">
      <Obelisk className="pointer-events-none absolute start-6 top-24 hidden h-28 w-6 text-gold opacity-10 md:block" />

      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12 text-center">
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.25em] text-gold">{t.location.label}</p>
          <h2 className="font-heading text-3xl font-bold text-[var(--gem-text)] sm:text-4xl">{t.location.title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-[var(--gem-text-soft)]">{t.location.subtitle}</p>
          <HieroglyphBorder className="mx-auto mt-4 h-5 w-40 text-gold opacity-60" />
        </div>

        <div className="grid gap-6 lg:grid-cols-5">
          {/* Map */}
          <div className="lg:col-span-3">
            <div className="overflow-hidden rounded-2xl gem-glass p-1.5 shadow-kohl">
              <iframe
                title={isAr ? 'خريطة المتحف المصري الكبير' : 'Grand Egyptian Museum map'}
                src={contact.mapsEmbedSrc}
                className="h-[420px] w-full rounded-xl border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            </div>
          </div>

          {/* Address card */}
          <div className="lg:col-span-2 flex flex-col justify-center rounded-2xl gem-glass p-7">
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--gem-gold-soft)] text-gold">
                <MapPin className="h-6 w-6" aria-hidden="true" />
              </span>
              <h3 className="font-heading text-xl font-bold text-[var(--gem-text)]">{t.location.address}</h3>
            </div>
            <p className="text-base leading-relaxed text-[var(--gem-text-soft)]">{address}</p>
            <p className="mt-3 text-sm text-gold/80">{t.location.subtitle}</p>

            <a
              href={contact.mapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center justify-center gap-2 rounded-full gem-btn-gold px-6 py-3 text-sm font-semibold"
            >
              <Navigation className="h-4 w-4" aria-hidden="true" />
              {t.location.directions}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
