// src/components/EgyptianPattern.jsx
// Inline SVG decorative elements that recolor with theme via currentColor.
// Reusable across sections.

export function PyramidMotif({ className = 'h-8 w-8 text-gold' }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" aria-hidden="true">
      <path d="M32 6 L58 56 L6 56 Z" stroke="currentColor" strokeWidth="2" />
      <path d="M32 6 L32 56" stroke="currentColor" strokeWidth="1.2" opacity="0.5" />
      <path d="M32 6 L20 56 L44 56 Z" stroke="currentColor" strokeWidth="1" opacity="0.35" />
    </svg>
  );
}

export function WingedSunDisk({ className = 'h-6 w-24 text-gold' }) {
  return (
    <svg viewBox="0 0 120 40" className={className} fill="none" aria-hidden="true">
      <circle cx="60" cy="20" r="9" stroke="currentColor" strokeWidth="2" />
      <path d="M51 20 Q30 6 6 14 Q26 18 51 22 Z" fill="currentColor" opacity="0.85" />
      <path d="M69 20 Q90 6 114 14 Q94 18 69 22 Z" fill="currentColor" opacity="0.85" />
      <path d="M6 14 L2 10 M114 14 L118 10" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

export function EyeOfHorus({ className = 'h-6 w-8 text-gold' }) {
  return (
    <svg viewBox="0 0 48 32" className={className} fill="none" aria-hidden="true">
      <path
        d="M4 16 Q14 6 26 10 Q38 14 44 16 Q38 18 26 22 Q14 26 4 16 Z"
        stroke="currentColor"
        strokeWidth="2"
      />
      <circle cx="22" cy="15" r="3" fill="currentColor" />
      <path d="M26 22 Q30 28 36 28" stroke="currentColor" strokeWidth="2" />
      <path d="M18 22 L16 28" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

export function Scarab({ className = 'h-6 w-7 text-gold' }) {
  return (
    <svg viewBox="0 0 56 40" className={className} fill="none" aria-hidden="true">
      <ellipse cx="28" cy="20" rx="14" ry="18" stroke="currentColor" strokeWidth="2" />
      <path d="M28 4 L28 36" stroke="currentColor" strokeWidth="1.2" opacity="0.5" />
      <path d="M28 12 Q16 14 10 22 M28 12 Q40 14 46 22" stroke="currentColor" strokeWidth="1.5" />
      <path d="M28 22 Q18 24 14 30 M28 22 Q38 24 42 30" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="28" cy="8" r="3" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

export function Ankh({ className = 'h-6 w-5 text-gold' }) {
  return (
    <svg viewBox="0 0 40 56" className={className} fill="none" aria-hidden="true">
      <ellipse cx="20" cy="14" rx="10" ry="11" stroke="currentColor" strokeWidth="2.5" />
      <path d="M20 25 L20 52" stroke="currentColor" strokeWidth="2.5" />
      <path d="M8 34 L32 34" stroke="currentColor" strokeWidth="2.5" />
    </svg>
  );
}

export function LotusColumn({ className = 'h-24 w-10 text-gold' }) {
  return (
    <svg viewBox="0 0 40 120" className={className} fill="none" aria-hidden="true">
      <path d="M20 6 Q14 12 14 20 Q14 28 20 30 Q26 28 26 20 Q26 12 20 6 Z" stroke="currentColor" strokeWidth="2" />
      <rect x="16" y="30" width="8" height="78" stroke="currentColor" strokeWidth="1.5" />
      <rect x="8" y="108" width="24" height="8" rx="2" stroke="currentColor" strokeWidth="2" />
      <path d="M16 36 L24 36 M16 46 L24 46 M16 56 L24 56 M16 66 L24 66 M16 76 L24 76 M16 86 L24 86 M16 96 L24 96" stroke="currentColor" strokeWidth="1" opacity="0.45" />
    </svg>
  );
}

export function Obelisk({ className = 'h-32 w-8 text-gold' }) {
  return (
    <svg viewBox="0 0 32 140" className={className} fill="none" aria-hidden="true">
      <path d="M16 4 L24 30 L24 126 L8 126 L8 30 Z" stroke="currentColor" strokeWidth="2" />
      <path d="M16 4 L16 126" stroke="currentColor" strokeWidth="1" opacity="0.4" />
      <rect x="4" y="126" width="24" height="8" rx="1" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

// Hieroglyph-style repeating border / divider
export function HieroglyphBorder({ className = 'h-6 w-full text-gold opacity-60' }) {
  return (
    <svg viewBox="0 0 240 24" className={className} fill="none" preserveAspectRatio="none" aria-hidden="true">
      <line x1="0" y1="12" x2="240" y2="12" stroke="currentColor" strokeWidth="1" />
      {Array.from({ length: 12 }).map((_, i) => (
        <circle key={i} cx={10 + i * 20} cy="12" r="1.6" fill="currentColor" />
      ))}
    </svg>
  );
}

// Cartouche-style frame wrapper for titles
export function Cartouche({ children, className = '' }) {
  return (
    <span className={`relative inline-block ${className}`}>
      <span className="relative z-10">{children}</span>
      <svg
        viewBox="0 0 300 80"
        preserveAspectRatio="none"
        className="absolute inset-0 h-full w-full text-gold"
        fill="none"
        aria-hidden="true"
      >
        <path
          d="M40 6 Q10 6 10 40 Q10 74 40 74 L260 74 Q290 74 290 40 Q290 6 260 6 Z"
          stroke="currentColor"
          strokeWidth="2.5"
        />
        <path
          d="M46 14 Q18 14 18 40 Q18 66 46 66 L254 66 Q282 66 282 40 Q282 14 254 14 Z"
          stroke="currentColor"
          strokeWidth="1"
          opacity="0.4"
        />
        <line x1="30" y1="6" x2="30" y2="74" stroke="currentColor" strokeWidth="1" opacity="0.5" />
        <line x1="270" y1="6" x2="270" y2="74" stroke="currentColor" strokeWidth="1" opacity="0.5" />
      </svg>
    </span>
  );
}

// Full-width decorative pyramid silhouette band
export function PyramidBand({ className = 'h-16 w-full text-gold opacity-20' }) {
  return (
    <svg viewBox="0 0 800 100" className={className} fill="none" preserveAspectRatio="none" aria-hidden="true">
      <path d="M0 100 L120 30 L220 100 Z" stroke="currentColor" strokeWidth="1.5" />
      <path d="M180 100 L320 10 L440 100 Z" stroke="currentColor" strokeWidth="1.5" />
      <path d="M400 100 L540 40 L660 100 Z" stroke="currentColor" strokeWidth="1.5" />
      <path d="M600 100 L740 20 L860 100 Z" stroke="currentColor" strokeWidth="1.5" />
      <line x1="0" y1="100" x2="800" y2="100" stroke="currentColor" strokeWidth="1" />
    </svg>
  );
}

// Triangle facade pattern (GEM-inspired)
export function FacadePattern({ className = 'h-32 w-full text-gold opacity-10' }) {
  const cols = 16;
  return (
    <svg viewBox="0 0 800 120" className={className} fill="none" preserveAspectRatio="none" aria-hidden="true">
      {Array.from({ length: cols }).map((_, i) => {
        const x = (i / (cols - 1)) * 800;
        return <path key={i} d={`M${x} 120 L${x + 25} 0 L${x + 50} 120 Z`} stroke="currentColor" strokeWidth="0.8" />;
      })}
    </svg>
  );
}

export default {
  PyramidMotif,
  WingedSunDisk,
  EyeOfHorus,
  Scarab,
  Ankh,
  LotusColumn,
  Obelisk,
  HieroglyphBorder,
  Cartouche,
  PyramidBand,
  FacadePattern,
};
