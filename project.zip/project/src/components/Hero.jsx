// src/components/Hero.jsx
// Full-screen hero with poster placeholder, museum name, tagline, CTAs.
// Gentle parallax on the background. Scrolls to sections.
import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { ChevronDown, Play } from 'lucide-react';
import { WingedSunDisk, PyramidBand, Cartouche } from './EgyptianPattern';
import { useState } from 'react';
import VideoModal from './VideoModal';
import { story } from '@/data/content';

export default function Hero() {
  const { t, isAr } = useLanguage();
  const bgRef = useRef(null);
  const [videoOpen, setVideoOpen] = useState(false);

  useEffect(() => {
    const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!fine || reduced) return;
    let raf;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        const y = window.scrollY;
        if (bgRef.current) bgRef.current.style.transform = `translate3d(0, ${y * 0.35}px, 0) scale(1.08)`;
        raf = null;
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const scrollTo = (id) => (e) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <section className="relative flex min-h-[100svh] items-center justify-center overflow-hidden">
      {/* Parallax background (placeholder poster) */}
      <div ref={bgRef} className="absolute inset-0 gem-parallax">
        <div className="absolute inset-0 gem-img-fallback animate-slow-zoom" aria-hidden="true" />
        {/* Triangle facade overlay */}
        <svg viewBox="0 0 800 600" className="absolute inset-0 h-full w-full text-gold opacity-10" fill="none" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          {Array.from({ length: 20 }).map((_, i) => {
            const x = (i / 19) * 800;
            return <path key={i} d={`M${x} 600 L${x + 20} 100 L${x + 40} 600 Z`} stroke="currentColor" strokeWidth="0.6" />;
          })}
        </svg>
        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-kohl/40 via-kohl/30 to-kohl/80" aria-hidden="true" />
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--gem-bg)] via-transparent to-transparent" aria-hidden="true" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-6 py-32 text-center">
        <div className="mb-6 flex justify-center animate-fade-in">
          <WingedSunDisk className="h-7 w-28 text-gold-light" />
        </div>

        <p className="mb-3 text-sm font-semibold uppercase tracking-[0.3em] text-gold-light animate-fade-up" style={{ animationDelay: '0.1s' }}>
          {t.locationNote}
        </p>

        <h1 className="font-heading text-4xl font-black leading-tight text-sandstone-light sm:text-6xl md:text-7xl animate-fade-up" style={{ animationDelay: '0.2s' }}>
          <span className="gem-text-gradient">{t.hero.title}</span>
        </h1>

        <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-sandstone-light/85 sm:text-lg animate-fade-up" style={{ animationDelay: '0.35s' }}>
          {t.hero.subtitle}
        </p>

        {/* CTAs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3 animate-fade-up" style={{ animationDelay: '0.5s' }}>
          <a href="#story" onClick={scrollTo('story')} className="gem-btn-gold inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold">
            {t.hero.ctaStory}
          </a>
          <Link to="/galleries" className="gem-btn-outline inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold text-sandstone-light">
            {t.hero.ctaGalleries}
          </Link>
          <Link to="/hours" className="gem-btn-outline inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold text-sandstone-light">
            {t.hero.ctaTickets}
          </Link>
          <button
            type="button"
            onClick={() => setVideoOpen(true)}
            aria-label={t.story.watch}
            className="group inline-flex h-12 w-12 items-center justify-center rounded-full border border-gold/60 bg-kohl/30 text-gold-light backdrop-blur-sm transition-all hover:scale-110 hover:bg-kohl/50"
          >
            <Play className="h-5 w-5 fill-current transition-transform group-hover:scale-110" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#story"
        onClick={scrollTo('story')}
        className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2 animate-bounce text-gold-light/80 transition-colors hover:text-gold-light"
        aria-label={t.hero.scroll}
      >
        <ChevronDown className="h-6 w-6" aria-hidden="true" />
      </a>

      <PyramidBand className="absolute bottom-0 left-0 z-[5] h-16 w-full text-gold opacity-25" />

      <VideoModal
        open={videoOpen}
        onClose={() => setVideoOpen(false)}
        videoSrc={story.video}
        poster={story.poster}
        titleAr={story.titleAr}
        titleEn={story.titleEn}
      />
    </section>
  );
}
