// src/components/GalleriesSection.jsx
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { galleries } from '@/data/content';
import ItemCard from './ItemCard';
import { HieroglyphBorder, LotusColumn } from './EgyptianPattern';

export default function GalleriesSection() {
  const { t } = useLanguage();
  const revealRef = useScrollReveal();

  return (
    <section id="galleries" ref={revealRef} className="gem-reveal relative scroll-mt-24 py-20 sm:py-28">
      {/* Decorative columns */}
      <LotusColumn className="pointer-events-none absolute start-4 top-20 hidden h-40 w-8 text-gold opacity-10 lg:block" />
      <LotusColumn className="pointer-events-none absolute end-4 top-20 hidden h-40 w-8 text-gold opacity-10 lg:block" />

      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12 text-center">
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.25em] text-gold">{t.galleries.label}</p>
          <h2 className="font-heading text-3xl font-bold text-[var(--gem-text)] sm:text-4xl">{t.galleries.title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-[var(--gem-text-soft)]">{t.galleries.subtitle}</p>
          <HieroglyphBorder className="mx-auto mt-4 h-5 w-40 text-gold opacity-60" />
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {galleries.map((g) => (
            <ItemCard
              key={g.id}
              item={g}
              exploreTo={`/galleries/${g.slug}`}
              exploreLabel={t.galleries.explore}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
