// src/data/content.js
// =============================================================
// ALL site content lives here: story, galleries, artifacts,
// opening hours, tickets, contact info, and media paths.
//
//  >> HOW TO REPLACE IMAGES & VIDEOS <<
//  1. Drop your files into /public/images/... and /public/videos/...
//     using the exact filenames referenced in `poster` and `video` below.
//  2. Missing image  -> automatic styled gradient fallback (no error).
//  3. Missing video  -> modal shows a "coming soon" message.
//
//  >> HOW TO EDIT TEXT <<
//  - Edit the *Ar and *En fields for each item.
//  - UI buttons/labels live in src/data/translations.js
//
//  Placeholders marked [PLACEHOLDER] are meant to be filled in.
// =============================================================

export const story = {
  slug: 'story',
  poster: '/images/story/museum-story.jpg', // <- replace with your image
  video: '/videos/museum-story.mp4', // <- replace with your video (optional videoAr / videoEn)
  titleAr: 'حكاية المتحف المصري الكبير',
  titleEn: 'The Story of the Grand Egyptian Museum',
  paragraphsAr: [
    'على بُعد خطوات من أهرامات الجيزة، يقوم المتحف المصري الكبير ليكون أكبر متحف في العالم مخصصاً لحضارة واحدة. مبنى يجمع بين العمارة المعاصرة وروح مصر القديمة، بواجهة شفافة تتلألأ كأنها حجر جيري ضخم.',
    'يضم المتحف عشرات الآلاف من الآثار، أبرزها المجموعة الكاملة للملك توت عنخ آمون، التي تُعرض لأول مرة في سياق واحد، إلى جانب التماثيل الضخمة والمراكب والكنوز التي رحلت عبر آلاف السنين.',
    'هنا لا تُقرأ التاريخ فحسب، بل تعيشه: من قاعة توت عنخ آمون إلى الدرج العظيم الذي يستقبلك بتماثيل الملوك، ثم إلى متحف الطفل حيث تبدأ الحكاية للأجيال القادمة.',
  ],
  paragraphsEn: [
    'Steps away from the Pyramids of Giza rises the Grand Egyptian Museum, the largest museum in the world dedicated to a single civilization. Its architecture blends contemporary design with the spirit of Ancient Egypt, with a translucent facade that glows like a monumental block of limestone.',
    'The museum houses tens of thousands of artifacts, most notably the complete collection of King Tutankhamun, displayed together for the first time, alongside colossal statues, boats, and treasures that have journeyed across millennia.',
    'Here history is not merely read, it is lived: from the Tutankhamun Halls to the Grand Staircase that welcomes you with statues of kings, and on to the Children’s Museum where the story begins for generations to come.',
  ],
  factsAr: [
    { label: 'الفكرة', value: '[PLACEHOLDER — السنة]' },
    { label: 'بدء الإنشاء', value: '[PLACEHOLDER — السنة]' },
    { label: 'الافتتاح', value: '[PLACEHOLDER — السنة]' },
    { label: 'الموقع', value: 'الجيزة – قرب الأهرامات' },
  ],
  factsEn: [
    { label: 'Idea', value: '[PLACEHOLDER — year]' },
    { label: 'Construction begins', value: '[PLACEHOLDER — year]' },
    { label: 'Opening', value: '[PLACEHOLDER — year]' },
    { label: 'Location', value: 'Giza — near the Pyramids' },
  ],
};

export const galleries = [
  {
    id: 'g-tut',
    slug: 'tutankhamun-halls',
    poster: '/images/galleries/tutankhamun-halls.jpg', // <- replace
    video: '/videos/tutankhamun-halls.mp4', // <- replace
    titleAr: 'قاعات توت عنخ آمون',
    titleEn: 'Tutankhamun Halls',
    descriptionAr:
      'تعرض لأول مرة المجموعة الكاملة لآثار الملك توت عنخ آمون، من القناع الذهبي الشهير إلى مقتنيات المقبرة، في قاعات تروي حكاية الملك الذهبى.',
    descriptionEn:
      'For the first time, the complete collection of King Tutankhamun is displayed, from the famous golden mask to the tomb belongings, in halls that tell the story of the golden king.',
  },
  {
    id: 'g-main',
    slug: 'main-hall',
    poster: '/images/galleries/main-hall.jpg', // <- replace
    video: '/videos/main-hall.mp4', // <- replace
    titleAr: 'القاعة الرئيسية',
    titleEn: 'Main Hall',
    descriptionAr:
      'بهو ضخم يستقبلك بتماثيل الملوك والآثار الكبرى، ويشكل نقطة الانطلاق لرحلتك داخل المتحف.',
    descriptionEn:
      'A vast hall welcomes you with statues of kings and major artifacts, serving as the starting point of your journey through the museum.',
  },
  {
    id: 'g-staircase',
    slug: 'grand-staircase',
    poster: '/images/galleries/grand-staircase.jpg', // <- replace
    video: '/videos/grand-staircase.mp4', // <- replace
    titleAr: 'الدرج العظيم',
    titleEn: 'Grand Staircase',
    descriptionAr:
      'سلم مهيب يتوسطه تماثيل ضخمة للملوك، يصعد بك رويداً رويداً بين روائح الزمن نحو أروقة المتحف.',
    descriptionEn:
      'A majestic staircase lined with colossal statues of kings, gently ascending through the wonders of time toward the museum wings.',
  },
  {
    id: 'g-children',
    slug: 'children-museum',
    poster: '/images/galleries/children-museum.jpg', // <- replace
    video: '/videos/children-museum.mp4', // <- replace
    titleAr: 'متحف الطفل',
    titleEn: "Children's Museum",
    descriptionAr:
      'مساحة تفاعلية تجعل حكاية مصر القديمة في متناول الأطفال عبر التجربة واللعب والاكتشاف.',
    descriptionEn:
      'An interactive space that brings the story of Ancient Egypt within children’s reach through experience, play, and discovery.',
  },
];

export const artifacts = [
  {
    id: 'a-ramses',
    slug: 'ramses-ii',
    poster: '/images/artifacts/ramses-ii.jpg', // <- replace
    video: '/videos/ramses-ii.mp4', // <- replace
    titleAr: 'تمثال رمسيس الثاني',
    titleEn: 'Statue of Ramses II',
    descriptionAr:
      'تمثال ضخم من الجرانيت للملك رمسيس الثاني، أحد أعظم ملوك مصر القديمة، يُستقبلك عند بوابة المتحف.',
    descriptionEn:
      'A colossal granite statue of King Ramses II, one of the greatest pharaohs of Ancient Egypt, greeting you at the museum entrance.',
  },
  {
    id: 'a-tut-collection',
    slug: 'tutankhamun-collection',
    poster: '/images/artifacts/tutankhamun-collection.jpg', // <- replace
    video: '/videos/tutankhamun-collection.mp4', // <- replace
    titleAr: 'مجموعة الملك توت عنخ آمون',
    titleEn: 'Tutankhamun Collection',
    descriptionAr:
      'أكثر من خمسة آلاف قطعة من مقبرة الملك الشاب توت عنخ آمون، تُعرض كاملة لأول مرة، وتشمل القناع الذهبي والعربة الحربية والمجوهرات.',
    descriptionEn:
      'More than five thousand pieces from the tomb of the boy-king Tutankhamun, displayed in full for the first time, including the golden mask, the chariot, and the jewelry.',
  },
  {
    id: 'a-merenptah',
    slug: 'merenptah-column',
    poster: '/images/artifacts/merenptah-column.jpg', // <- replace
    video: '/videos/merenptah-column.mp4', // <- replace
    titleAr: 'عمود الملك مرنبتاح',
    titleEn: 'Column of King Merenptah',
    descriptionAr:
      'عمود ضخم للملك مرنبتاح إلى جانب تماثيل عملاقة أخرى، يبرز عمارة المعابد وفنون النحت في عصر الدولة الحديثة.',
    descriptionEn:
      'A colossal column of King Merenptah alongside other giant statues, highlighting temple architecture and sculpture of the New Kingdom era.',
  },
  {
    id: 'a-solar-boats',
    slug: 'solar-boats',
    poster: '/images/artifacts/solar-boats.jpg', // <- replace
    video: '/videos/solar-boats.mp4', // <- replace
    titleAr: 'مراكب الشمس',
    titleEn: 'Solar Boats',
    descriptionAr:
      'مراكب خشبية عملاقة دُفنت بجوار الأهرامات لحمل الملك في رحلته الأبدية، شاهدة على براعة صناع السفن في مصر القديمة.',
    descriptionEn:
      'Giant wooden boats buried beside the pyramids to carry the king on his eternal journey, a testament to the shipwrights’ skill of Ancient Egypt.',
  },
];

// Opening hours — replace [PLACEHOLDER] with real values.
export const openingHours = {
  rowsAr: [
    { day: 'السبت – الخميس', hours: '[PLACEHOLDER — ٩:٠٠ ص – ٦:٠٠ م]' },
    { day: 'الجمعة', hours: '[PLACEHOLDER — ١:٠٠ م – ٨:٠٠ م]' },
  ],
  rowsEn: [
    { day: 'Saturday – Thursday', hours: '[PLACEHOLDER — 9:00 AM – 6:00 PM]' },
    { day: 'Friday', hours: '[PLACEHOLDER — 1:00 PM – 8:00 PM]' },
  ],
  notesAr: 'يُفضّل الحجز المسبق عبر الإنترنت. آخر دخول قبل الإغلاق بساعة.',
  notesEn: 'Online pre-booking is recommended. Last entry one hour before closing.',
};

// Ticket categories — replace [PLACEHOLDER] prices with real values.
export const tickets = {
  rowsAr: [
    { category: 'المصريون البالغون', price: '[PLACEHOLDER] ج.م', notes: 'بإثبات الهوية' },
    { category: 'الطلاب المصريون', price: '[PLACEHOLDER] ج.م', notes: 'بطاقة جامعية' },
    { category: 'الأطفال (تحت ٦ سنوات)', price: 'مجاناً', notes: 'بمرافق بالغ' },
    { category: 'الأجانب البالغون', price: '[PLACEHOLDER] ج.م', notes: 'شامل كل القاعات' },
    { category: 'الطلاب الأجانب', price: '[PLACEHOLDER] ج.م', notes: 'بطاقة جامعية دولية' },
  ],
  rowsEn: [
    { category: 'Egyptian adults', price: '[PLACEHOLDER] EGP', notes: 'ID required' },
    { category: 'Egyptian students', price: '[PLACEHOLDER] EGP', notes: 'Student card' },
    { category: 'Children (under 6)', price: 'Free', notes: 'With an adult' },
    { category: 'Foreign adults', price: '[PLACEHOLDER] EGP', notes: 'All galleries included' },
    { category: 'Foreign students', price: '[PLACEHOLDER] EGP', notes: 'International student card' },
  ],
};

// Contact placeholders — replace with real info.
export const contact = {
  phone: '[PLACEHOLDER — +20 0XX XXX XXXX]',
  email: '[PLACEHOLDER — info@gem.org.eg]',
  addressAr: 'القاهرة – طريق الإسكندرية الصحراوي، الجيزة، مصر',
  addressEn: 'Cairo – Alexandria Desert Road, Giza, Egypt',
  mapsEmbedSrc:
    'https://www.google.com/maps?q=Grand+Egyptian+Museum,+Giza,+Egypt&output=embed',
  mapsDirectionsUrl:
    'https://www.google.com/maps/dir/?api=1&destination=Grand+Egyptian+Museum,+Giza,+Egypt',
};

export default { story, galleries, artifacts, openingHours, tickets, contact };
