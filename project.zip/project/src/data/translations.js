// src/data/translations.js
// =============================================================
// UI strings for the entire site. Edit text here.
// Language keys: 'ar' (Arabic, default) and 'en' (English).
// =============================================================

export const translations = {
  ar: {
    // Brand
    museumName: 'المتحف المصري الكبير',
    museumShort: 'المتحف الكبير',
    tagline: 'حضارة مصر القديمة بين يديك',
    locationNote: 'الجيزة – بالقرب من أهرامات الجيزة',

    // Navbar
    nav: {
      home: 'الرئيسية',
      story: 'حكاية المتحف',
      galleries: 'القاعات',
      artifacts: 'أهم القطع الأثرية',
      hours: 'مواعيد العمل والتذاكر',
      location: 'الموقع',
    },
    langToggleLabel: 'English',
    langToggleAria: 'التبديل إلى اللغة الإنجليزية',
    themeToggleToDark: 'التبديل إلى الوضع الليلي',
    themeToggleToLight: 'التبديل إلى الوضع النهاري',
    openMenu: 'فتح القائمة',
    closeMenu: 'إغلاق القائمة',

    // Hero
    hero: {
      title: 'المتحف المصري الكبير',
      subtitle: 'أكبر متحف في العالم مخصص لحضارة واحدة.. على مرمى البصر من أهرامات الجيزة',
      ctaStory: 'اكتشف الحكاية',
      ctaGalleries: 'تصفّح القاعات',
      ctaTickets: 'احجز تذكرتك',
      scroll: 'اكتشف المزيد',
    },

    // Story
    story: {
      label: 'حكاية المتحف',
      title: 'حكاية المتحف المصري الكبير',
      watch: 'شاهد الحكاية',
      learnMore: 'اقرأ الحكاية كاملة',
      factsLabel: 'محطات أساسية',
    },

    // Galleries
    galleries: {
      label: 'القاعات',
      title: 'قاعات المتحف',
      subtitle: 'أربعة أجنحة رئيسية تأخذك في رحلة عبر آلاف السنين',
      watch: 'شاهد الفيديو',
      explore: 'استكشف القاعة',
    },

    // Artifacts
    artifacts: {
      label: 'أهم القطع الأثرية',
      title: 'كنوز المتحف',
      subtitle: 'قطع نادرة تجسّد عظمة مصر القديمة',
      watch: 'شاهد الفيديو',
      explore: 'استكشف القطعة',
    },

    // Detail page
    detail: {
      back: 'رجوع',
      watchVideo: 'شاهد الفيديو',
      prev: 'السابق',
      next: 'التالي',
      prevItem: 'القطعة السابقة',
      nextItem: 'القطعة التالية',
    },

    // Video modal
    video: {
      title: 'فيديو',
      close: 'إغلاق',
      comingSoon: 'الفيديو قريباً',
      comingSoonDesc: 'يتم العمل على إضافة هذا الفيديو حالياً. يرجى العودة لاحقاً.',
    },

    // Hours & tickets
    hours: {
      label: 'مواعيد العمل والتذاكر',
      title: 'مواعيد العمل والتذاكر',
      subtitle: 'خطط لزيارتك إلى المتحف المصري الكبير في الجيزة',
      openingTitle: 'مواعيد العمل',
      ticketsTitle: 'فئات التذاكر',
      category: 'الفئة',
      price: 'السعر',
      notes: 'ملاحظات',
      getTickets: 'احجز تذاكرك',
      book: 'احجز الآن',
      booking: {
        title: 'حجز تذكرة الزيارة',
        subtitle: 'اختر فئة التذكرة واملأ بياناتك لاستلام باركود التذكرة',
        category: 'فئة التذكرة',
        quantity: 'العدد',
        name: 'الاسم',
        namePlaceholder: 'الاسم بالكامل',
        email: 'البريد الإلكتروني',
        emailPlaceholder: 'example@email.com',
        date: 'تاريخ الزيارة',
        confirm: 'تأكيد الحجز',
        cancel: 'إلغاء',
        success: 'تم تأكيد حجزك!',
        successDesc: 'احتفظ بهذا الباركود واعرضه عند بوابة المتحف.',
        ticketNo: 'رقم التذكرة',
        download: 'حفظ الباركود',
        close: 'إغلاق',
        total: 'الإجمالي',
        free: 'مجاناً',
        enterName: 'من فضلك أدخل الاسم',
        enterEmail: 'من فضلك أدخل البريد الإلكتروني',
        chooseCategory: 'من فضلك اختر فئة التذكرة',
        invalidEmail: 'البريد الإلكتروني غير صحيح',
        bookingFor: 'حجز لـ',
        person: 'شخص',
        people: 'أشخاص',
        visitDate: 'تاريخ الزيارة',
        poweredBy: 'نظام تجريبي للحجز — البيانات لا تُحفظ على خادم',
      },
    },

    // Location
    location: {
      label: 'الموقع الجغرافي',
      title: 'الموقع الجغرافي',
      subtitle: 'المتحف المصري الكبير – الجيزة، بالقرب من أهرامات الجيزة',
      address: 'العنوان',
      directions: 'احصل على الاتجاهات',
      addressValue: 'القاهرة – طريق الإسكندرية الصحراوي، الجيزة، مصر',
    },

    // Footer
    footer: {
      about: 'عن المتحف',
      quickLinks: 'روابط سريعة',
      contact: 'تواصل معنا',
      rights: 'جميع الحقوق محفوظة',
      phone: 'الهاتف',
      email: 'البريد الإلكتروني',
      address: 'العنوان',
      disclaimer:
        'هذا موقع تجريبي للمتحف المصري الكبير في الجيزة، ولا يمثل الموقع الرسمي. هذا متحف مختلف عن المتحف المصري بميدان التحرير وسط القاهرة.',
      follow: 'تابعنا',
      siteQr: 'امسح لزيارة الموقع',
      siteQrDesc: 'وجّه كاميرا هاتفك للباركود لفتح الموقع مباشرةً',
    },
  },

  en: {
    museumName: 'Grand Egyptian Museum',
    museumShort: 'GEM',
    tagline: 'Ancient Egypt within reach',
    locationNote: 'Giza — near the Giza Pyramids',

    nav: {
      home: 'Home',
      story: 'The Story',
      galleries: 'Galleries',
      artifacts: 'Key Artifacts',
      hours: 'Hours & Tickets',
      location: 'Location',
    },
    langToggleLabel: 'ع',
    langToggleAria: 'Switch to Arabic',
    themeToggleToDark: 'Switch to dark mode',
    themeToggleToLight: 'Switch to light mode',
    openMenu: 'Open menu',
    closeMenu: 'Close menu',

    hero: {
      title: 'Grand Egyptian Museum',
      subtitle: 'The largest museum in the world dedicated to a single civilization, within sight of the Pyramids of Giza',
      ctaStory: 'Discover the Story',
      ctaGalleries: 'Browse Galleries',
      ctaTickets: 'Book Tickets',
      scroll: 'Explore more',
    },

    story: {
      label: 'The Story of the Museum',
      title: 'The Story of the Grand Egyptian Museum',
      watch: 'Watch the Story',
      learnMore: 'Read the full story',
      factsLabel: 'Key milestones',
    },

    galleries: {
      label: 'Galleries',
      title: 'Museum Galleries',
      subtitle: 'Four main halls take you on a journey across thousands of years',
      watch: 'Watch Video',
      explore: 'Explore Gallery',
    },

    artifacts: {
      label: 'Key Artifacts',
      title: 'Museum Treasures',
      subtitle: 'Rare pieces that embody the greatness of Ancient Egypt',
      watch: 'Watch Video',
      explore: 'Explore Artifact',
    },

    detail: {
      back: 'Back',
      watchVideo: 'Watch Video',
      prev: 'Previous',
      next: 'Next',
      prevItem: 'Previous item',
      nextItem: 'Next item',
    },

    video: {
      title: 'Video',
      close: 'Close',
      comingSoon: 'Video coming soon',
      comingSoonDesc: 'This video is being prepared. Please check back later.',
    },

    hours: {
      label: 'Opening Hours & Tickets',
      title: 'Opening Hours & Tickets',
      subtitle: 'Plan your visit to the Grand Egyptian Museum in Giza',
      openingTitle: 'Opening Hours',
      ticketsTitle: 'Ticket Categories',
      category: 'Category',
      price: 'Price',
      notes: 'Notes',
      getTickets: 'Book your tickets',
      book: 'Book now',
      booking: {
        title: 'Book your visit ticket',
        subtitle: 'Choose a ticket category and fill in your details to receive your ticket QR code',
        category: 'Ticket category',
        quantity: 'Quantity',
        name: 'Full name',
        namePlaceholder: 'Your full name',
        email: 'Email',
        emailPlaceholder: 'example@email.com',
        date: 'Visit date',
        confirm: 'Confirm booking',
        cancel: 'Cancel',
        success: 'Your booking is confirmed!',
        successDesc: 'Keep this QR code and show it at the museum gate.',
        ticketNo: 'Ticket number',
        download: 'Save QR code',
        close: 'Close',
        total: 'Total',
        free: 'Free',
        enterName: 'Please enter your name',
        enterEmail: 'Please enter your email',
        chooseCategory: 'Please choose a ticket category',
        invalidEmail: 'Invalid email address',
        bookingFor: 'Booking for',
        person: 'person',
        people: 'people',
        visitDate: 'Visit date',
        poweredBy: 'Demo booking system — data is not stored on a server',
      },
    },

    location: {
      label: 'Location',
      title: 'Location',
      subtitle: 'Grand Egyptian Museum — Giza, near the Pyramids of Giza',
      address: 'Address',
      directions: 'Get Directions',
      addressValue: 'Cairo – Alexandria Desert Road, Giza, Egypt',
    },

    footer: {
      about: 'About the Museum',
      quickLinks: 'Quick Links',
      contact: 'Contact',
      rights: 'All rights reserved',
      phone: 'Phone',
      email: 'Email',
      address: 'Address',
      disclaimer:
        'This is a demo website for the Grand Egyptian Museum in Giza and does not represent the official site. This is a different museum from the Egyptian Museum in Tahrir Square, Downtown Cairo.',
      follow: 'Follow us',
      siteQr: 'Scan to visit the site',
      siteQrDesc: 'Point your phone camera at the QR code to open the website directly',
    },
  },
};

export default translations;
