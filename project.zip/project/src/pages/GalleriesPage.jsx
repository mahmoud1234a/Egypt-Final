// src/pages/GalleriesPage.jsx (listing) and gallery detail handled via route.
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { galleries } from '@/data/content';
import ItemCard from '@/components/ItemCard';
import { HieroglyphBorder, LotusColumn } from '@/components/EgyptianPattern';

export default function GalleriesPage() {
  const { t } = useLanguage();
  const revealRef = useScrollReveal();
  return (
    <section ref={revealRef} className="gem-reveal pt-32 pb-20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12 text-center">
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.25em] text-gold">{t.galleries.label}</p>
          <h2 className="font-heading text-3xl font-bold text-[var(--gem-text)] sm:text-4xl">{t.galleries.title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-[var(--gem-text-soft)]">{t.galleries.subtitle}</p>
          <HieroglyphBorder className="mx-auto mt-4 h-5 w-40 text-gold opacity-60" />
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {galleries.map((g) => (
            <ItemCard key={g.id} item={g} exploreTo={`/galleries/${g.slug}`} exploreLabel={t.galleries.explore} />
          ))}
        </div>
      </div>
    </section>
  );
}
