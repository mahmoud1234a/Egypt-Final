// src/pages/NotFound.jsx
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { PyramidMotif } from '@/components/EgyptianPattern';

export default function NotFound() {
  const { isAr, t } = useLanguage();
  return (
    <div className="flex min-h-[80vh] flex-col items-center justify-center px-6 text-center">
      <div className="mb-6 flex justify-center text-gold opacity-80">
        <PyramidMotif className="h-16 w-16" />
      </div>
      <p className="font-heading text-5xl font-black gem-text-gradient">404</p>
      <p className="mt-4 text-lg text-[var(--gem-text-soft)]">
        {isAr ? 'لم يتم العثور على هذه الصفحة' : 'This page was not found'}
      </p>
      <Link to="/" className="mt-6 gem-btn-gold inline-flex items-center rounded-full px-6 py-3 text-sm font-semibold">
        {isAr ? 'العودة للرئيسية' : 'Back to Home'}
      </Link>
      <span className="sr-only">{t.museumName}</span>
    </div>
  );
}
