// src/pages/HoursPage.jsx
import HoursSection from '@/components/HoursSection';

export default function HoursPage() {
  return (
    <div className="pt-16">
      <HoursSection />
    </div>
  );
}
