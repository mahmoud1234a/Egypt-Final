// src/pages/LocationPage.jsx
import LocationSection from '@/components/LocationSection';

export default function LocationPage() {
  return (
    <div className="pt-16">
      <LocationSection />
    </div>
  );
}
