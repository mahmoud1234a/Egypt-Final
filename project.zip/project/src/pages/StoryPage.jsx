// src/pages/StoryPage.jsx
// Full standalone story page: hero poster, all paragraphs, facts, video.
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { story } from '@/data/content';
import SmartImage from '@/components/SmartImage';
import VideoButton from '@/components/VideoButton';
import { HieroglyphBorder, PyramidBand, EyeOfHorus, WingedSunDisk } from '@/components/EgyptianPattern';

export default function StoryPage() {
  const { t, isAr } = useLanguage();
  const revealRef = useScrollReveal();
  useEffect(() => { window.scrollTo({ top: 0 }); }, []);

  const title = isAr ? story.titleAr : story.titleEn;
  const paragraphs = isAr ? story.paragraphsAr : story.paragraphsEn;
  const facts = isAr ? story.factsAr : story.factsEn;
  const Chevron = isAr ? ChevronLeft : ChevronRight;

  return (
    <article className="pt-20">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="relative h-[60vh] min-h-[380px] w-full">
          <SmartImage src={story.poster} alt={title} titleAr={story.titleAr} titleEn={story.titleEn} rounded={false} className="h-full w-full" />
          <div className="absolute inset-0 bg-gradient-to-t from-kohl via-kohl/45 to-kohl/30" aria-hidden="true" />
          <PyramidBand className="absolute bottom-0 left-0 h-14 w-full text-gold opacity-25" />
        </div>
        <div className="absolute inset-x-0 bottom-0 p-6 sm:p-10">
          <div className="mx-auto max-w-5xl">
            <div className="mb-3 flex justify-start">
              <WingedSunDisk className="h-6 w-24 text-gold-light opacity-90" />
            </div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.3em] text-gold-light">{t.story.label}</p>
            <h1 className="font-heading text-3xl font-black text-sandstone-light sm:text-5xl">{title}</h1>
          </div>
        </div>
      </section>

      {/* Body */}
      <section ref={revealRef} className="gem-reveal py-14">
        <div className="mx-auto max-w-5xl px-6">
          <div className="mb-8 flex items-center gap-2 text-sm text-[var(--gem-text-soft)]">
            <Link to="/" className="gem-link">{t.nav.home}</Link>
            <Chevron className={`h-4 w-4 ${isAr ? 'rotate-180' : ''}`} aria-hidden="true" />
            <span className="text-gold">{t.nav.story}</span>
          </div>

          <div className="grid gap-10 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="mb-4 flex items-center gap-2 text-gold">
                <EyeOfHorus className="h-5 w-7" />
                <span className="text-xs font-semibold uppercase tracking-widest">{t.story.label}</span>
              </div>
              <h2 className="font-heading text-2xl font-bold text-[var(--gem-text)] sm:text-3xl">{title}</h2>
              <HieroglyphBorder className="mt-3 h-5 w-32 text-gold opacity-50" />

              <div className="mt-6 space-y-5">
                {paragraphs.map((p, i) => (
                  <p key={i} className="text-base leading-[2] text-[var(--gem-text-soft)] sm:text-lg">{p}</p>
                ))}
              </div>

              {/* Facts */}
              <h3 className="mt-10 mb-4 font-heading text-lg font-bold text-[var(--gem-text)]">{t.story.factsLabel}</h3>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {facts.map((f, i) => (
                  <div key={i} className="rounded-xl border border-[var(--gem-border)] bg-[var(--gem-surface)] p-4 text-center">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-gold/80">{f.label}</p>
                    <p className="mt-1 text-sm font-medium text-[var(--gem-text)]">{f.value}</p>
                  </div>
                ))}
              </div>
            </div>

            <aside className="lg:col-span-1">
              <div className="sticky top-28 gem-glass rounded-2xl p-6 text-center">
                <SmartImage src={story.poster} alt={title} titleAr={story.titleAr} titleEn={story.titleEn} className="aspect-video w-full mb-5" />
                <VideoButton video={story.video} poster={story.poster} titleAr={story.titleAr} titleEn={story.titleEn} label={t.story.watch} className="w-full" />
              </div>
            </aside>
          </div>

          <div className="mt-12 text-center">
            <Link to="/" className="inline-flex items-center gap-2 text-sm font-semibold text-gold hover:text-gold-light">
              <ChevronLeft className={`h-4 w-4 ${isAr ? 'rotate-180' : ''}`} aria-hidden="true" />
              {t.detail.back}
            </Link>
          </div>
        </div>
      </section>
    </article>
  );
}
