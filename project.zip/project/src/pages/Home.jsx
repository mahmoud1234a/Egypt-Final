// src/pages/Home.jsx
import Hero from '@/components/Hero';
import StorySection from '@/components/StorySection';
import GalleriesSection from '@/components/GalleriesSection';
import ArtifactsSection from '@/components/ArtifactsSection';
import HoursSection from '@/components/HoursSection';
import LocationSection from '@/components/LocationSection';

export default function Home() {
  return (
    <>
      <Hero />
      <StorySection />
      <GalleriesSection />
      <ArtifactsSection />
      <HoursSection />
      <LocationSection />
    </>
  );
}
