// src/pages/ArtifactsPage.jsx
import { useLanguage } from '@/context/LanguageContext';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { artifacts } from '@/data/content';
import ItemCard from '@/components/ItemCard';
import { HieroglyphBorder, Scarab } from '@/components/EgyptianPattern';

export default function ArtifactsPage() {
  const { t } = useLanguage();
  const revealRef = useScrollReveal();
  return (
    <section ref={revealRef} className="gem-reveal pt-32 pb-20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12 text-center">
          <div className="mb-3 flex justify-center text-gold"><Scarab className="h-7 w-8" /></div>
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-gold">{t.artifacts.label}</p>
          <h2 className="font-heading text-3xl font-bold text-[var(--gem-text)] sm:text-4xl">{t.artifacts.title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-[var(--gem-text-soft)]">{t.artifacts.subtitle}</p>
          <HieroglyphBorder className="mx-auto mt-4 h-5 w-40 text-gold opacity-60" />
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {artifacts.map((a) => (
            <ItemCard key={a.id} item={a} exploreTo={`/artifacts/${a.slug}`} exploreLabel={t.artifacts.explore} />
          ))}
        </div>
      </div>
    </section>
  );
}
