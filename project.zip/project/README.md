# نظام الحجز – المتحف المصري الكبير

موقع حجز مستقل (Node.js + Express + SQLite + Nodemailer). الواجهة والخادم في مشروع واحد.

## التشغيل محليًا
1. ثبّت Node 18 أو أحدث.
2. `npm install`
3. انسخ `.env.example` إلى `.env` واملأ بيانات SMTP و`ADMIN_TOKEN`.
4. `npm start` ثم افتح http://localhost:3000

## التخصيص
- `config.js`: الأماكن والأسعار والمواعيد والسعة. **الأسعار الحالية أمثلة مؤقتة، عدّلها.**
- `public/style.css`: الألوان (متغيرات `:root` في أعلى الملف).

## ربط زر "Book Now" في موقعك
غيّر رابط الزر ليشير إلى عنوان موقع الحجز بعد نشره:
```html
<a href="https://YOUR-BOOKING-SITE.com" target="_blank" rel="noopener">احجز الآن</a>
```
وفي `.env` ضع `MUSEUM_URL` برابط موقعك الأساسي ليظهر زر العودة.

## النشر
انشره على خدمة تدعم Node (Render / Railway / VPS). قاعدة SQLite ملف على القرص، فاستخدم **قرصًا دائمًا (Persistent Disk)** وضع `DB_PATH` عليه، وإلا ستضيع الحجوزات عند إعادة تشغيل الخدمة.

## عرض الحجوزات
`GET /api/admin/bookings` مع الهيدر `x-admin-token: <ADMIN_TOKEN>`.
