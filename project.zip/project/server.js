require('dotenv').config();
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const express = require('express'), Database = require('better-sqlite3'), nodemailer = require('nodemailer');
const C = require('./config');

/* ---------- قاعدة البيانات ---------- */
const dbPath = process.env.DB_PATH || path.join(__dirname, 'data', 'bookings.db');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS bookings(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL,
  location_id TEXT NOT NULL, location_name TEXT NOT NULL, date TEXT NOT NULL, slot TEXT NOT NULL,
  visitors INTEGER NOT NULL, unit_price INTEGER NOT NULL, total INTEGER NOT NULL, currency TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed', email_status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_slot ON bookings(location_id, date, slot);
`);
const usedStmt = db.prepare(`SELECT COALESCE(SUM(visitors),0) n FROM bookings WHERE location_id=? AND date=? AND slot=? AND status='confirmed'`);
const insertStmt = db.prepare(`INSERT INTO bookings(id,name,email,phone,location_id,location_name,date,slot,visitors,unit_price,total,currency)
  VALUES(@id,@name,@email,@phone,@location_id,@location_name,@date,@slot,@visitors,@unit_price,@total,@currency)`);

/* ---------- أدوات ---------- */
const cairoToday = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Cairo' });
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const validDate = s => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s + 'T00:00:00Z')) && addDays(s, 0) === s;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const newId = () => `GEM-${cairoToday().replace(/-/g, '')}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

function validate(b) {
  const e = {}, o = {};
  o.name = String(b.name || '').trim().replace(/\s+/g, ' ');
  if (o.name.length < 3 || o.name.length > 80) e.name = 'من فضلك أدخل الاسم الكامل (3 أحرف على الأقل).';
  o.email = String(b.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(o.email) || o.email.length > 120) e.email = 'أدخل بريدًا إلكترونيًا صحيحًا.';
  o.phone = String(b.phone || '').trim();
  if (!/^\+?[0-9\s-]{8,16}$/.test(o.phone) || o.phone.replace(/\D/g, '').length < 8) e.phone = 'أدخل رقم هاتف صحيحًا (8 إلى 15 رقمًا).';
  const loc = C.locations.find(l => l.id === b.location);
  if (!loc) e.location = 'اختر المكان.'; else o.loc = loc;
  o.date = String(b.date || '');
  const today = cairoToday();
  if (!validDate(o.date)) e.date = 'اختر تاريخًا صحيحًا.';
  else if (o.date < today) e.date = 'لا يمكن الحجز في تاريخ سابق.';
  else if (o.date > addDays(today, C.maxAdvanceDays)) e.date = `أقصى مدة للحجز المسبق ${C.maxAdvanceDays} يومًا.`;
  o.slot = String(b.slot || '');
  if (!C.slots.includes(o.slot)) e.slot = 'اختر موعدًا متاحًا.';
  o.visitors = Number(b.visitors);
  if (!Number.isInteger(o.visitors) || o.visitors < 1 || o.visitors > C.maxVisitors) e.visitors = `عدد الزوار من 1 إلى ${C.maxVisitors}.`;
  return { e, o };
}

/* ---------- البريد ---------- */
const mailer = process.env.SMTP_HOST && process.env.SMTP_USER
  ? nodemailer.createTransport({ host: process.env.SMTP_HOST, port: +(process.env.SMTP_PORT || 587), secure: +(process.env.SMTP_PORT) === 465, auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } })
  : null;

function emailHtml(b) {
  const row = (k, v) => `<tr><td style="padding:10px 14px;color:#9aa6c0;border-bottom:1px solid #1d2a4d">${k}</td><td style="padding:10px 14px;color:#fff;font-weight:700;border-bottom:1px solid #1d2a4d">${esc(v)}</td></tr>`;
  return `<!doctype html><html lang="ar" dir="rtl"><body style="margin:0;background:#070e22;font-family:Tahoma,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
<table width="600" style="max-width:100%;background:#0b1a3f;border:1px solid #d4b24c;border-radius:16px;overflow:hidden">
<tr><td style="padding:28px;text-align:center;background:linear-gradient(180deg,#0f2252,#0b1a3f)">
<div style="color:#d4b24c;font-size:26px;font-weight:700">المتحف المصري الكبير</div>
<div style="color:#cfd6e6;margin-top:6px">تأكيد الحجز</div></td></tr>
<tr><td style="padding:24px 28px;color:#e6eaf5;line-height:1.9">
مرحبًا ${esc(b.name)}،<br>تم تأكيد حجزك بنجاح. رقم الحجز الخاص بك:
<div style="margin:14px 0;padding:14px;text-align:center;border:1px dashed #d4b24c;border-radius:12px;color:#d4b24c;font-size:22px;font-weight:700;letter-spacing:1px;direction:ltr">${esc(b.id)}</div>
<table width="100%" cellspacing="0" style="background:#0a1636;border-radius:12px">
${row('المكان', b.location_name)}${row('التاريخ', b.date)}${row('الموعد', b.slot)}${row('عدد الزوار', b.visitors)}
${row('سعر الفرد', b.unit_price + ' ' + b.currency)}${row('الإجمالي', b.total + ' ' + b.currency)}${row('الهاتف', b.phone)}</table>
<p style="color:#9aa6c0;font-size:13px">يرجى إبراز رقم الحجز عند الوصول. إذا لم تقم بهذا الحجز فتجاهل هذه الرسالة.</p>
</td></tr></table></td></tr></table></body></html>`;
}

async function sendConfirmation(b) {
  if (!mailer) { console.warn('SMTP غير مُعد: لم يُرسل بريد للحجز', b.id); return 'not_configured'; }
  try {
    await mailer.sendMail({ from: process.env.MAIL_FROM || process.env.SMTP_USER, to: b.email, subject: `تأكيد الحجز ${b.id} – المتحف المصري الكبير`, html: emailHtml(b),
      text: `تم تأكيد حجزك. رقم الحجز: ${b.id}\n${b.location_name}\n${b.date} – ${b.slot}\nعدد الزوار: ${b.visitors}\nالإجمالي: ${b.total} ${b.currency}` });
    return 'sent';
  } catch (err) { console.error('فشل إرسال البريد:', err.message); return 'failed'; }
}

/* ---------- التطبيق ---------- */
const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '20kb' }));
app.use((req, res, next) => { res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin' }); next(); });
app.use(express.static(path.join(__dirname, 'public')));

const hits = new Map();
const limiter = (req, res, next) => {
  const now = Date.now(), arr = (hits.get(req.ip) || []).filter(t => now - t < 15 * 60e3);
  if (arr.length >= 10) return res.status(429).json({ ok: false, message: 'محاولات كثيرة. حاول بعد قليل.' });
  arr.push(now); hits.set(req.ip, arr); next();
};

app.get('/api/config', (req, res) => {
  const today = cairoToday();
  res.json({ currency: C.currency, maxVisitors: C.maxVisitors, slots: C.slots, minDate: today, maxDate: addDays(today, C.maxAdvanceDays),
    museumUrl: process.env.MUSEUM_URL || '', locations: C.locations.map(({ id, name, price }) => ({ id, name, price })) });
});

app.get('/api/availability', (req, res) => {
  const loc = C.locations.find(l => l.id === req.query.location), date = String(req.query.date || '');
  if (!loc || !validDate(date)) return res.status(400).json({ ok: false });
  res.json({ ok: true, slots: C.slots.map(s => ({ slot: s, remaining: Math.max(0, loc.capacity - usedStmt.get(loc.id, date, s).n) })) });
});

app.post('/api/bookings', limiter, async (req, res) => {
  const { e, o } = validate(req.body || {});
  if (Object.keys(e).length) return res.status(400).json({ ok: false, errors: e, message: 'يرجى تصحيح الحقول المحددة.' });
  let booking;
  try {
    booking = db.transaction(() => {
      if (o.loc.capacity - usedStmt.get(o.loc.id, o.date, o.slot).n < o.visitors) { const x = new Error('FULL'); x.full = true; throw x; }
      const row = { id: newId(), name: o.name, email: o.email, phone: o.phone, location_id: o.loc.id, location_name: o.loc.name, date: o.date, slot: o.slot,
        visitors: o.visitors, unit_price: o.loc.price, total: o.loc.price * o.visitors, currency: C.currency };
      insertStmt.run(row); return row;
    })();
  } catch (err) {
    if (err.full) return res.status(409).json({ ok: false, errors: { slot: 'هذا الموعد لا يتسع لعدد الزوار المطلوب. اختر موعدًا آخر.' }, message: 'الموعد غير متاح.' });
    console.error(err); return res.status(500).json({ ok: false, message: 'تعذّر حفظ الحجز. حاول مرة أخرى.' });
  }
  // الحجز محفوظ فعليًا في قاعدة البيانات قبل هذه النقطة
  const emailStatus = await sendConfirmation(booking);
  db.prepare('UPDATE bookings SET email_status=? WHERE id=?').run(emailStatus, booking.id);
  res.status(201).json({ ok: true, emailStatus, booking: { id: booking.id, name: booking.name, email: booking.email, location: booking.location_name, date: booking.date, slot: booking.slot, visitors: booking.visitors, unitPrice: booking.unit_price, total: booking.total, currency: booking.currency } });
});

app.get('/api/admin/bookings', (req, res) => {
  const t = Buffer.from(String(req.get('x-admin-token') || '')), k = Buffer.from(process.env.ADMIN_TOKEN || '');
  if (!k.length || t.length !== k.length || !crypto.timingSafeEqual(t, k)) return res.status(401).json({ ok: false });
  res.json({ ok: true, bookings: db.prepare('SELECT * FROM bookings ORDER BY created_at DESC LIMIT 500').all() });
});

app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(process.env.PORT || 3000, () => console.log('Booking server on port', process.env.PORT || 3000));
